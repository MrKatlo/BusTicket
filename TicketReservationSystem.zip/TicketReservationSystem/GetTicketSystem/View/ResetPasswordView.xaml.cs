﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.Remoting.Messaging;
using System.Security.Policy;

namespace GetTicketSystem.View
{
    /// <summary>
    /// Interaction logic for ResetPasswordView.xaml
    /// </summary>
    public partial class ResetPasswordView : Window
    {
        SqlConnection conn=new SqlConnection(@"Data Source=DESKTOP-GEIT3P6;Initial Catalog=GetTicketSystem;Integrated Security=True");
        public ResetPasswordView()
        {
            
            InitializeComponent();
            newpassborder.Opacity = 0;
            confirmnewpassborder.Opacity = 0;
            btnback.Margin = new Thickness(0,-50,0,0);
            btnsearch.Margin= new Thickness(50,-50,0,0);
            stchange.Opacity = 0;           


        } 
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }
        public void btnMinimize_click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            LoginView login= new LoginView();
            login.Show();
            this.Close();
        }

        private void btnsearch_Click(object sender, RoutedEventArgs e)
        { 
           /* if(searchinput.Text.Length > 0)
            {
                try
                {
                    conn.Open();
                    SqlCommand bash = new SqlCommand();
                    SqlDataReader reader;
                    bash = new SqlCommand("select * from Customers where Email=@Email and Password=@Password", conn);
                    bash.Parameters.AddWithValue("@Email", searchinput.Text);
                    reader = bash.ExecuteReader();
                    if (reader.HasRows)
                    {
                        btnsearch.Opacity = 0;
                        stchange.Margin = new Thickness(120, -40, 0, 0);
                        btnback.Margin = new Thickness(0, 5, 0, 0);
                        stchange.Opacity = 1;
                        bdsearch.Opacity = 0;
                        confirmnewpassborder.Opacity = 1;
                        newpassborder.Opacity = 1;
                        promt.Text = "Good new! Your account was found.\n      Please create new password.";
                    }
                    else
                    {
                        promt.Text = "Sorry! account not found.\n     Try again or Register new account";

                    }*/

               /*     conn.Close();
                }
                catch
                {
                    MessageBox.Show("not working");
                }*/
               
            }
           

          
            

         
        }
    }

