﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Runtime.Remoting.Contexts;

namespace GetTicketSystem.View
{
    /// <summary>
    /// Interaction logic for AdminView.xaml
    /// </summary>
    public partial class AdminView : Window
    {
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-GEIT3P6;Initial Catalog=GetTicketSystem;Integrated Security=True");
        public AdminView()
        {

            InitializeComponent();
            
            
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        public void btnMinimize_click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnCreateSchedule_Click(object sender, RoutedEventArgs e)
            //add schedule to DB
        {
            if (BUSID.Text == "BUS ID" && txtdriver.Text == "DRIVER" && txtFrom.Text == "FROM" && txtTo.Text == "TO" && txtarrive.Text == "ARRIVE" && txtdepature.Text == "DEPATURE")
            {
                MessageBox.Show("PLEASE EDIT THE SCHEDULE FORM");
            }
            else
            {
                conn.Open();
                SqlCommand comm = conn.CreateCommand();
                comm.CommandType = CommandType.Text;
                comm.CommandText = "insert into BUS_SCHEDULES values(NEWID(),'" + BUSID.Text.ToLower() + "','" + txtdriver.Text.ToLower() + "','" + txtFrom.Text.ToLower() + "','" + txtTo.Text.ToLower() + "','" + txtdepature.Text.ToLower() + "','" + txtarrive.Text.ToLower() + "')";
                comm.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Schedule Created");
                BUSID.Text = "BUS ID";
                txtdriver.Text = "DRIVE ";
                txtFrom.Text = "FROM";
                txtTo.Text = "TO";
                txtarrive.Text = "ARRIVE";
                txtdepature.Text = "DEPATURE";
            }
           
            
        }

        private void txtFrom_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtFrom.Text == "")
            {
                txtFrom.Text = "FROM";
            }
        }

        private void txtFrom_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtFrom.Text== "FROM")
            {
                txtFrom.Text = "";
            }
           
        }
        private void txtTo_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtTo.Text == "")
            { 
                
                txtTo.Text = "TO";
            }
        }

        private void txtTo_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtTo.Text == "TO")
            {
                txtTo.Text = "";
            }

        }

        private void BUSID_LostFocus(object sender, RoutedEventArgs e)
        {
            {
                if (BUSID.Text == "")
                {

                    BUSID.Text = "BUS ID";
                }
            }
        }

        private void BUSID_GotFocus(object sender, RoutedEventArgs e)
        {
            if (BUSID.Text == "BUS ID")
            {
                BUSID.Text = "";
            }
        }

        private void txtdriver_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtdriver.Text == "")
            {
                txtdriver.Text = "DRIVER";
            }
        }
        private void txtdriver_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtdriver.Text == "DRIVER")
            {
                txtdriver.Text = "";
            }
        }

        private void txtdepature_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtdepature.Text == "")
            {
                txtdepature.Text = "DEPATURE";
            }
        }

        private void txtdepature_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtdepature.Text == "DEPATURE")
            {
                txtdepature.Text = "";
            }
        }

        private void txtarrive_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtarrive.Text == "ARRIVE")
            {
                txtarrive.Text = "";
            }
        }

        private void txtarrive_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtarrive.Text == "")
            {
                txtarrive.Text = "ARRIVE";
            }
        }

       
    }
}
