﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Net.Mail;
using System.Web;

namespace GetTicketSystem.View
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class RegisterView: Window
    {
        SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-GEIT3P6;Initial Catalog=GetTicketSystem;Integrated Security=True");
        public RegisterView()
        {
            InitializeComponent();
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        public void btnMinimize_click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            LoginView login = new LoginView();
            login.Show();
            this.Close();
        }
        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
          if(txtEmail.Text.Length > 0|| txtFirstname.Text.Length>0|| txtLastname.Text.Length>0||txtconfirmPassword.Password.Length>0|| txtcreatePassword.Password.Length>0 ) {

                if (txtcreatePassword.Password==txtconfirmPassword.Password)
                {
                    connect.Open();
                    SqlCommand comm = connect.CreateCommand();
                    comm.CommandType = CommandType.Text;
                    comm.CommandText = "insert into Customers values(NEWID(),'" + txtFirstname.Text + "','" + txtLastname.Text + "','" + txtEmail.Text + "','" + txtEmail.Text + "','" + txtconfirmPassword.Password + "')";
                    comm.ExecuteNonQuery();
                    connect.Close();
                    MessageBox.Show("Record Inserted");

                }
                else
                {
                    MessageBox.Show("Password Don't match");

                }
               
            }
            else
            {
                MessageBox.Show("Please Fill All Field");
            }
           
        }
    }
}
