﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace GetTicketSystem.View
{
    /// <summary>
    /// Interaction logic for DashboardView.xaml
    /// </summary>
    public partial class DashboardView : Window
    {
       
        public string toContent;
        public int Num { get; set; }
        public double Pr4 = 0;
        // to store autocomplete list from DB

        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-GEIT3P6;Initial Catalog=GetTicketSystem;Integrated Security=True");
        
        private T FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(parent, i);
                if (child != null && child is T)
                {
                    return (T)child;
                }
                else
                {
                    T foundChild = FindVisualChild<T>(child);
                    if (foundChild != null)
                    {
                        return foundChild;
                    }
                }
            }
            return null;
        }


        //autocomplete content /button
        public void displaydata(string dbfrom, string dbfromtime, string dbto, string dbtotime, string dbprice)
        {


            Border border = new Border
            {
                Width = high01.Width,
                Height = high01.Height,
                BorderBrush = high01.BorderBrush,
                BorderThickness = high01.BorderThickness,
                Margin = high01.Margin,
                CornerRadius = high01.CornerRadius,
                Background = high01.Background,
                Effect = high01.Effect,
            };
            StackPanel stackPanel = new StackPanel();
            Grid grid = new Grid();
            Border pic2 = new Border
            {
                Width = pic.Width,
                Height = pic.Height,
                BorderBrush = pic.BorderBrush,
                BorderThickness = pic.BorderThickness,
                Margin = pic.Margin,
                CornerRadius = pic.CornerRadius,
                Background = pic.Background,
                HorizontalAlignment = pic.HorizontalAlignment,
                VerticalAlignment = pic.VerticalAlignment,
            };
            StackPanel panel = new StackPanel
            {
                Margin = detail.Margin,
                Background = detail.Background,
                Height = detail.Height,
                Width = detail.Width,
            };
            StackPanel fordetails = new StackPanel
            {
                Orientation = Orientation.Horizontal,
            };
            StackPanel fordetailz = new StackPanel
            {
                Orientation = Orientation.Horizontal,
            };
            StackPanel details2 = new StackPanel
            {
                Background = detail.Background,
                Height = detail.Height,
                Width = detail.Width,

            };
            Grid grid1 = new Grid
            {

            };
            foreach (ColumnDefinition coldef in grid2.ColumnDefinitions)
            {
                ColumnDefinition newcol = new ColumnDefinition();
                ColumnDefinition newcol1 = new ColumnDefinition();
                newcol.Width = coldef.Width;

                newcol1.Width = coldef.Width;
                grid1.ColumnDefinitions.Add(newcol);
                grid1.ColumnDefinitions.Add(newcol1);
            }

            foreach (RowDefinition Rowdef in grid2.RowDefinitions)
            {
                RowDefinition newRol = new RowDefinition();
                RowDefinition newRol1 = new RowDefinition();
                newRol.Height = Rowdef.Height;
                newRol1.Height = Rowdef.Height;
                grid1.RowDefinitions.Add(newRol);
                grid1.RowDefinitions.Add(newRol1);
            }
            TextBlock from1 = new TextBlock
            {
                Text = dbfrom,
                FontSize = from.FontSize,
                FontWeight = from.FontWeight,
                Margin = new Thickness(10, 10, -50, 0),
               
                TextAlignment = TextAlignment.Left,
                
            };

            Grid.SetColumn(from1, 0);
            Grid.SetRow(from1, 0);

            TextBlock fromtime1 = new TextBlock
            {
                Text = dbfromtime + "hrs",
                FontSize = from.FontSize,
                FontWeight = from.FontWeight,
                Margin = new Thickness(10, 20, -50, 0),


            };

            Grid.SetColumn(fromtime1, 0);
            Grid.SetRow(fromtime1, 1);

            TextBlock to1 = new TextBlock
            {
                Text = dbto,
               
                TextAlignment = TextAlignment.Left,
                FontSize = from.FontSize,
                FontWeight = from.FontWeight,
               
                Margin = new Thickness(100, 10, -170, 0),

            };

            Grid.SetColumn(to1, 1);
            Grid.SetRow(to1, 0);

            TextBlock toTime = new TextBlock
            {
                Text = dbtotime + "hrs",
                FontSize = from.FontSize,
                FontWeight = from.FontWeight,
                Margin = new Thickness(10, 20, -200, 0),

                Width = 100

            };

            Grid.SetColumn(toTime, 1);
            Grid.SetRow(toTime, 1);
            StackPanel select = new StackPanel
            {
                Background = new SolidColorBrush(Colors.Transparent),
                Width = 170,
            };
            TextBlock price = new TextBlock
            {
                Text = dbprice,
                Name = "Price",
                Foreground = price1.Foreground,
                FontWeight = price1.FontWeight,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = price1.Margin,
                FontSize = price1.FontSize,
            };
            Button book = new Button
            {
                FontSize = Bookbus.FontSize,
                Foreground = Bookbus.Foreground,

                FontWeight = Bookbus.FontWeight,
            };
            book.Style = Bookbus.Style;
            book.Template = Bookbus.Template;
            book.ContentTemplate = Bookbus.ContentTemplate;
            book.Click += new RoutedEventHandler(BOOK01_Click);
            select.Children.Add(price);
            select.Children.Add(book);
            fordetails.Children.Add(pic2);
            grid1.Children.Add(from1);
            grid1.Children.Add(fromtime1);
            grid1.Children.Add(to1);
            grid1.Children.Add(toTime);
            details2.Children.Add(grid1);
            fordetailz.Children.Add(details2);
            fordetails.Children.Add(fordetailz);
            fordetails.Children.Add(select);

            grid.Children.Add(fordetails);
            border.Child = grid;
            Highlights.Children.Add(border);


        }


        public void confirm(string from, string fromtime, string to, string totime,string Cost,string date)
        {
                     
            Window window = new Window();
            window.WindowStyle = WindowStyle.None;
            window.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            window.ShowInTaskbar = false;
            window.Width = 400;
            window.Height = 400;
            window.Background = new SolidColorBrush(Colors.Transparent);
            window.AllowsTransparency = true;
            Border border = new Border
            {
                Background = new SolidColorBrush(Colors.White),
                CornerRadius = high01.CornerRadius,
                Width = 380,
                Height = 380,
                BorderThickness = new Thickness(3),
                BorderBrush = new SolidColorBrush(Colors.Green),
            };
            StackPanel forclose = new StackPanel
            {
                VerticalAlignment = VerticalAlignment.Top,
                HorizontalAlignment = HorizontalAlignment.Right,
            };
            Button close = new Button
            {
                FontSize = btnClose1.FontSize,
                Foreground = btnClose1.Foreground,
                Margin = new Thickness(0, 1, 2, 0),
                Padding = new Thickness(0, 0, 0, 50),
                FontWeight = btnClose1.FontWeight,
            };
            close.Style = btnClose1.Style;
            ControlTemplate template = new ControlTemplate();
            template.TargetType = typeof(Button);
            Border temp = new Border
            {
                Background = new SolidColorBrush(Colors.Red),
                CornerRadius = high01.CornerRadius,
                Height = 18,
                Width = 20,
            };

            ContentPresenter content = new ContentPresenter
            {
                Content = "X",
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
            };
            temp.Child = content;
            string xaml = @"
    <ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='Button'>
        <Border Width=""20"" Height=""18""
                                    CornerRadius=""9""
                                    Background=""{TemplateBinding Background}""
                                         >
                                    <ContentPresenter
                                        Content=""x""
                                          Margin=""5,-8,0,0""
                                          
                                        >

                                       
                                    </ContentPresenter>


                                </Border>
    </ControlTemplate>
"; string xaml4 = @"
    <ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='Button'>
        <Border Width=""20"" Height=""18""
                                    CornerRadius=""9""
                                    Background=""{TemplateBinding Background}""
                                         >
                                    <ContentPresenter
                                        Content=""+""
                                       Margin=""2.8,-6,0,0""
                                          
                                        >

                                       
                                    </ContentPresenter>


                                </Border>
    </ControlTemplate>
";

            string Pr = Cost;
          
            string Pr2 = Cost.Trim('P','p');
            double Pr3 = double.Parse(Pr2);
            Pr4 = Pr3;
            string xaml5 = @"
    <ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='Button'>
        <Border Width=""20"" Height=""18""
                                    CornerRadius=""9""
                                    Background=""{TemplateBinding Background}""
                                         >
                                    <ContentPresenter
                                        Content=""-""
                                          Margin=""6,-8,0,0""
                                          
                                        >

                                       
                                    </ContentPresenter>


                                </Border>
    </ControlTemplate>
"; f1.Text = from;
            f2.Text = to;
            f3.Text = Pr4.ToString();
            f4.Text = fromtime;
            f5.Text=totime; 
            f6.Text="Gaborone Bus Station";
            string price = $"{Pr4}";
            string Daa = File.ReadAllText("name.txt");
            string number = Num.ToString();
            File.WriteAllText("Price.txt", price);
           
           
            number = $"{Num}";
            string FROM = $"{from}";
            string FROMTIME = $"{fromtime}";
            string TO = $"{to}";
            string TOTIME = $"{totime}";
            string name = $"{Daa}";

            string xaml3 =

               "<StackPanel xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\"><Grid\r\nWidth=\"356\" Height=\"350\">\r\n  " +
                "          <Border CornerRadius=\"9\" Background=\"#121520\" Margin=\"0,3,0,0\" >   \r\n                <StackPanel >    \r\n                " +
                "" +
                "    <StackPanel Margin=\"10,20,0,0\" " +
                "Orientation=\"Horizontal\"\r\n   " +
                "                   Height=\"40\" \r\n                " +
                "        \r\n       " +
                "                 >\r\n                " +
                "        <TextBlock Text=\"Full Name\"\r\n     " +
                "                      Foreground=\"White\"\r\n                " +
                "           FontSize=\"17\"\r\n                       " +
                "    FontWeight=\"Bold\"\r\n            " +
                "               Margin=\"10,0,0,0\"\r\n                " +
                "           />\r\n                   " +
                "     <TextBlock Text=\"Date\"\r\n      " +
                "                     Margin=\"80,0,0,0\"\r\n                       " +
                "    Foreground=\"White\"\r\n       " +
                "                    FontSize=\"17\"\r\n        " +
                "                   FontWeight=\"Bold\"\r\n                 " +
                "          />\r\n              " +
                "      </StackPanel>\r\n          " +
                "          <StackPanel Margin=\"10,-15,0,0\"" +
                " Orientation=\"Horizontal\"\r\n          " +
                "            Height=\"40\"  >\r\n                        <TextBlock Text= \""+name+"\"\r\n                           Foreground=\"#FF67CC23\"\r\n         " +
                "                  FontSize=\"17\"\r\n                           FontWeight=\"Bold\"\r\n                           Margin=\"10,0,0,0\"\r\n           " +
                "                />\r\n                        <TextBlock Text=\""+date+"\"\r\n                           Margin=\"75,0,0,0\"\r\n                " +
                "           Foreground=\"#FF67CC23\"\r\n                           FontSize=\"17\"\r\n                           FontWeight=\"Bold\"\r\n            " +
                "               />\r\n                    </StackPanel>\r\n         " +
                "           <StackPanel Margin=\"10,-10,0,0\" Orientation=\"Horizontal\"\r\n          " +
                "            Height=\"40\"  >\r\n                      " +
                "  <TextBlock Text=\"Departing\"\r\n    " +
                "                       Foreground=\"White\"\r\n                    " +
                "       FontSize=\"17\"\r\n         " +
                "                  FontWeight=\"Bold\"\r\n    " +
                "                       Margin=\"10,0,0,0\"\r\n       " +
                "                    />\r\n       " +
                "                 <TextBlock Text=\"Destination\"\r\n       " +
                "                    Margin=\"80,0,0,0\"\r\n                 " +
                "          Foreground=\"White\"\r\n            " +
                "               FontSize=\"17\"\r\n                      " +
                "     FontWeight=\"Bold\"\r\n                           />\r\n               " +
                "     </StackPanel>\r\n            " +
                "        <StackPanel Margin=\"10,-10,0,0\" Orientation=\"Horizontal\"\r\n   " +
                "                   Height=\"40\"  >\r\n                    " +
                "    <TextBlock Text=   " + "\"" + FROM + "\"\r\n" +
                "                        Foreground=\"#FF67CC23\"\r\n                           FontSize=\"17\"\r\n                 " + "Width=\"118\"" +
                "          FontWeight=\"Bold\"\r\n                       " +
                "    Margin=\"10,0,0,0\"\r\n                           />\r\n    " +
                "                    <TextBlock Text=          " + "\"" + TO + "\"\r\n" +
                "                Margin=\"42,0,0,0\"\r\n         " +
                "" +
                "                  Foreground=\"#FF67CC23\"\r\n    " +
                "                       FontSize=\"17\"\r\n         " +
                "                  FontWeight=\"Bold\"\r\n         " +
                "                  />\r\n     " +

                "               </StackPanel>\r\n     " +
                "               <StackPanel Margin=\"10,-10,0,0\" Orientation=\"Horizontal\"\r\n     " +
                "                 Height=\"40\"  >\r\n                     " +
                "   <TextBlock Text=\"Departure\"\r\n                           Foreground=\"White\"\r\n                           FontSize=\"17\"\r\n                         " +
                "  FontWeight=\"Bold\"\r\n                           Margin=\"10,0,0,0\"\r\n                           />\r\n                        <TextBlock Text=\"Arrive\"\r\n      " +
                "                     Margin=\"80,0,0,0\"\r\n                           Foreground=\"White\"\r\n                           FontSize=\"17\"\r\n                        " +
                "   FontWeight=\"Bold\"\r\n                           />\r\n                    </StackPanel>\r\n        " +
                "            <StackPanel Margin=\"10,-10,0,0\" Orientation=\"Horizontal\"\r\n      " +
                "                Height=\"40\"  >\r\n                        <TextBlock Text=      " + "\"" + FROMTIME + "\"\r\n" +
                "                     Foreground=\"#FF67CC23\"\r\n                     " +
                "      FontSize=\"17\"\r\n                           FontWeight=\"Bold\"\r\n                           Margin=\"10,0,0,0\"\r\n                           />\r\n                 " +
                "       <TextBlock Text=    " + "\"" + TOTIME + "\"\r\n" +
                "                       Margin=\"95,0,0,0\"\r\n                           Foreground=\"#FF67CC23\"\r\n                        " +
                "   FontSize=\"17\"\r\n                           FontWeight=\"Bold\"\r\n                           />\r\n                    </StackPanel>\r\n                  " +
                "  <StackPanel Margin=\"0,0,0,0\" RenderTransformOrigin=\"0.5,0.661\">\r\n                        <Border HorizontalAlignment=\"Left\"  CornerRadius=\"3\" Width=\"358\" Height=\"28\"" +
                " BorderThickness=\"0,2,0,0\" BorderBrush=\"White\">\r\n            " +
                "                <StackPanel  x:Name=\"Passenger\" Orientation=\"Horizontal\">\r\n                             " +
                "   <TextBlock Text=\"Select Seat\"\r\n                           " +
                "        Margin=\"10,0,0,0\"\r\n                              " +
                " FontSize=\"18\"\r\n                               FontWeight=\"Bold\"\r\n    " +
                "                           Foreground=\"White\"\r\n                        />\r\n    " +
                "                            <Border Margin=\"10,0,0,0\" CornerRadius=\"9\" >\r\n        " +
                "                            <TextBlock  x:Name=\"Passengers\"                        " +
                "           Text=" + "\"" + number + "\"\r\n" + "Width =\"25\" "+

                "                                     FontSize=\"18\"\r\n    " +
                "                           FontWeight=\"Bold\"\r\n                                 " +
                "    Background=\"Transparent\" Foreground=\"#FF67CC23\"/>\r\n                          " +
                "      </Border>\r\n                            </StackPanel>\r\n                 " +
                "       </Border>\r\n                        <Border HorizontalAlignment=\"Left\" " +
                " CornerRadius=\"3\" Width=\"356\" Height=\"28\" BorderThickness=\"0,0,0,2\" BorderBrush=\"White\">\r\n     " +
                "                       <StackPanel Orientation=\"Horizontal\" >\r\n                              " +
                "  <TextBlock Text=\"Total Cost\"\r\n                                   Margin=\"10,0,0,0\"\r\n      " +
                "                         FontSize=\"18\"\r\n                               FontWeight=\"Bold\"\r\n     " +
                "                          Foreground=\"White\"\r\n                        />\r\n                        " +
                "        <Border Margin=\"18,0,0,0\" CornerRadius=\"9\" >\r\n                                    <TextBlock \r\n    " +
                "                                   Text=\""+"P"+price+".00"+"\"\r\n                                     " +
                "            Foreground=\"#FF67CC23\"\r\n              " +

                "                           FontSize=\"18\"\r\n                    " +
                "           FontWeight=\"Bold\"\r\n                              " +
                "       Background=\"Transparent\"  />\r\n                        " +
                "        </Border>\r\n                            </StackPanel>\r\n       " +
                "                 </Border>\r\n                    </StackPanel>\r\n    <StackPanel  x:Name=\"forbtn\" ></StackPanel>     " +
                "           <StackPanel Margin=\"0,10,0,0\">\r\n                        \r\n                    </StackPanel>\r\n                </StackPanel>\r\n      " +
                "      </Border>\r\n           </Grid></StackPanel>"
                ;

            byte[] byteArray = Encoding.UTF8.GetBytes(xaml3);
            MemoryStream stream = new MemoryStream(byteArray);

            StackPanel container = (StackPanel)XamlReader.Load(stream);


            ControlTemplate controlTemplate = (ControlTemplate)XamlReader.Parse(xaml);
            controlTemplate.TargetType = typeof(Button);

            /* close.ContentTemplate = btnClose1.ContentTemplate;*/
            close.Template = controlTemplate;
            close.Click += new RoutedEventHandler(pop_close);
            forclose.Children.Add(close);
            Button book = new Button
            {
                FontSize = Bookbus.FontSize,
                Foreground = Bookbus.Foreground,
                Margin = new Thickness(0, 10, 0, 0),
                FontWeight = Bookbus.FontWeight,
            };
            book.Style = Bookbus.Style;
            book.Template = Bookbus.Template;
            book.ContentTemplate = Bookbus.ContentTemplate;
           
            book.Click += new RoutedEventHandler(Confirm);
            // increase passenger 
            Button increase = new Button
            {
                FontSize = btnClose1.FontSize,
                Foreground = btnClose1.Foreground,
                Margin = new Thickness(0, 1, 30, 0),
                Padding = new Thickness(0, 0, 0, 50),
                FontWeight = btnClose1.FontWeight,
            };
            increase.Style = BookBus10.Style;
            ControlTemplate template1 = new ControlTemplate();
            template1.TargetType = typeof(Button);
            Border temp1 = new Border
            {
                Background = new SolidColorBrush(Colors.Red),
                CornerRadius = high01.CornerRadius,
                Height = 18,
                Width = 20,
            };

            ContentPresenter content1 = new ContentPresenter
            {
                Content = "X",
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
            };
            temp1.Child = content1;
            ControlTemplate controlTemplate1 = (ControlTemplate)XamlReader.Parse(xaml4);
            controlTemplate1.TargetType = typeof(Button);
            increase.Template = controlTemplate1;
            increase.Click += new RoutedEventHandler(addone);

            File.WriteAllText("Const.txt", Cost);
            //decrease passenger
            Button decrease = new Button
            {
                FontSize = btnClose1.FontSize,
                Foreground = btnClose1.Foreground,
                Margin = new Thickness(-35, 0, 0, 0),
                Padding = new Thickness(0, 0, 0, 0),
                FontWeight = btnClose1.FontWeight,
            };
            decrease.Style = close.Style;
            ControlTemplate template2 = new ControlTemplate();
            template2.TargetType = typeof(Button);

            Border temp2 = new Border
            {
                Background = new SolidColorBrush(Colors.Red),
                CornerRadius = high01.CornerRadius,
                Height = 18,
                Width = 20,
            };

            ContentPresenter content2 = new ContentPresenter
            {
                Content = "X",
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
            };
            temp2.Child = content2;
            ControlTemplate controlTemplate2 = (ControlTemplate)XamlReader.Parse(xaml5);
            controlTemplate2.TargetType = typeof(Button);

            /* close.ContentTemplate = btnClose1.ContentTemplate;*/
            decrease.Template = controlTemplate2;
            decrease.Click += new RoutedEventHandler(removeone);

            StackPanel stack1 = (StackPanel)container.FindName("forbtn");
            StackPanel stack2 = (StackPanel)container.FindName("Passenger");
            if (stack2 != null)
            {
                stack2.Children.Add(increase);
                stack2.Children.Add(decrease);
            }
            if (stack1 != null)
            {
                stack1.Children.Add(book);
            }

            StackPanel stack = new StackPanel();
            stack.Children.Add(forclose);

            stack.Children.Add(container);

            /* stack.Children.Add(book);*/
            border.Child = stack;
            
            window.Content = border;
            window.Show();
        }

        public void CreateTicket(string from, string fromtime, string to, string totime,string ID )
        {
            string Data = File.ReadAllText("name.txt");
            
           
                string name = $"{currentUser.Text}";
            string Id= $"{ID}";
            string FROM = $"{from}";
            string FROMTIME = $"{fromtime}";
            string TO = $"{to}";
            string TOTIME = $"{totime}";
            string joke = Data;
            string xaml = " <Grid xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' Margin=\"-11000,0,0,-340\" >\r\n     " +
                "   <StackPanel VerticalAlignment=\"Center\">\r\n          " +
                "  <Border Width=\"375\" Height=\"183\" CornerRadius=\"9\" Background=\"White\">\r\n            " +
                "    <StackPanel   >\r\n                    <Border Background=\"#FF97D83D\" CornerRadius=\"9,9,0,0\">\r\n        " +
                "                <StackPanel Orientation=\"Horizontal\"  Height=\"35\">\r\n                   " +
                "         <Label Content=\"BOARDING PASS\"\r\n                           " +
                "    Foreground=\"White\"\r\n                            " +
                "   FontSize=\"17\"\r\n                               Margin=\"10,0,0,0\"\r\n           " +
                "                    FontWeight=\"Bold\"/>\r\n                      " +
                "      <Label Content=\"BUS COMPANY\"\r\n                        " +
                "       Foreground=\"White\"\r\n                            " +
                "    Margin=\"80,0,0,0\"\r\n                          " +
                "     FontSize=\"17\"\r\n                         " +
                "      FontWeight=\"Bold\" \r\n                               />\r\n     " +
                "                   </StackPanel>\r\n\r\n                    </Border>\r\n         " +
                "           <StackPanel Height=\"118\">\r\n                     " +
                "   <StackPanel Orientation=\"Horizontal\">\r\n                    " +
                "        <Label Content=\"PASSENGER\"\r\n                     " +
                "           Margin=\"0,0,0,0\"\r\n                          " +
                "     FontSize=\"14\"\r\n                        " +
                "       FontWeight=\"Bold\" \r\n                    " +
                "           >\r\n                                <Label.Foreground>\r\n         " +
                "                           <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n         " +
                "                               <GradientStop Color=\"#FF00FF04\"/>\r\n                            " +
                "            <GradientStop Color=\"#FF110040\" Offset=\"1\"/>\r\n                             " +
                "       </LinearGradientBrush>\r\n                                </Label.Foreground>\r\n      " +
                "                      </Label>\r\n                            <Label Content=\"TICKET ID\"\r\n       " +
                "                         Margin=\"50,0,0,0\"\r\n                               FontSize=\"14\"\r\n      " +
                "                         FontWeight=\"Bold\" Background=\"White\" \r\n                               >\r\n      " +
                "                          <Label.Foreground>\r\n                           " +
                "         <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n     " +
                "                                   <GradientStop Color=\"#FF00FF04\"/>\r\n        " +
                "                                <GradientStop Color=\"#FF110040\" Offset=\"1\"/>\r\n         " +
                "                           </LinearGradientBrush>\r\n                          " +
                "      </Label.Foreground>\r\n                            </Label>\r\n           " +
                "                 <Label Content=\""+Id+" \"\r\n                        " +
                "        Margin=\"0,0,0,0\"\r\n                            " +
                "   FontSize=\"14\"\r\n                          " +
                "     FontWeight=\"Bold\" Background=\"#00000000\" \r\n    " +
                "                           >\r\n                             " +
                "   <Label.Foreground>\r\n                                " +
                "    <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n       " +
                "                                 <GradientStop Color=\"#FF1B2154\"/>\r\n               " +
                "                         <GradientStop Color=\"#FF110040\" Offset=\"1\"/>\r\n            " +
                "                        </LinearGradientBrush>\r\n                          " +
                "      </Label.Foreground>\r\n                            </Label>\r\n         " +
                "               </StackPanel>\r\n                        <StackPanel Orientation=\"Horizontal\">\r\n     " +
                "                       <Label Content=\""+joke+"\"\r\n                        " +
                "        Margin=\"0,-30,0,0\"\r\n                           " +
                "    FontSize=\"9\"\r\n                                   Height=\"20\"\r\n       " +
                "                        FontWeight=\"Bold\" \r\n                            " +
                "       Width=\"100\"\r\n                               >\r\n                " +
                "                <Label.Foreground>\r\n                             " +
                "       <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n   " +
                "                                     <GradientStop Color=\"#FF2B00FF\"/>\r\n                  " +
                "                      <GradientStop Color=\"#FF110040\" Offset=\"1\"/>\r\n         " +
                "                           </LinearGradientBrush>\r\n                          " +
                "      </Label.Foreground>\r\n                        " +
                "    </Label>\r\n                         " +
                "   <Label Content=\"FROM\"\r\n                         " +
                "       Margin=\"41,10,0,0\"\r\n                   " +
                "            FontSize=\"14\"\r\n               " +
                "                FontWeight=\"Bold\" Background=\"White\" \r\n             " +
                "                  >\r\n                          " +
                "      <Label.Foreground>\r\n                       " +
                "             <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n      " +
                "                                  <GradientStop Color=\"#FF00FF04\"/>\r\n       " +
                "                                 <GradientStop Color=\"#FF110040\" Offset=\"1\"/>\r\n    " +
                "                                </LinearGradientBrush>\r\n                          " +
                "      </Label.Foreground>\r\n                         " +
                "   </Label>\r\n                            <Label Content=\""+FROM+"\" \r\n     "+"      " +
                "                     Margin=\"25,10,0,0\"\r\n             " +
                "                  FontSize=\"14\"\r\n                    " +
                "           FontWeight=\"Bold\" Background=\"White\" \r\n         " +
                "                      >\r\n                             " +
                "   <Label.Foreground>\r\n                           " +
                "         <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n             " +
                "                           <GradientStop Color=\"#FF2A2D58\"/>\r\n                " +
                "                        <GradientStop Color=\"#FF110040\" Offset=\"1\"/>\r\n      " +
                "                              </LinearGradientBrush>\r\n                       " +
                "         </Label.Foreground>\r\n                      " +
                "      </Label>\r\n                    " +
                "    </StackPanel>\r\n                  " +
                "      <StackPanel Orientation=\"Horizontal\">\r\n      " +
                "                      <Label Content=\"DEPATURE\"\r\n              " +
                "                  Margin=\"0,-60,0,0\"\r\n                  " +
                "             FontSize=\"14\"\r\n                         " +
                "         \r\n                               FontWeight=\"Bold\" \r\n     " +
                "                              Width=\"100\" Height=\"25\" Background=\"#00F1F1F1\"\r\n        " +
                "                       >\r\n                            " +
                "    <Label.Foreground>\r\n                         " +
                "           <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n     " +
                "                                   <GradientStop Color=\"#FF00FF04\"/>\r\n     " +
                "                                   <GradientStop Color=\"#FF110040\" Offset=\"1\"/>\r\n         " +
                "                           </LinearGradientBrush>\r\n                          " +
                "      </Label.Foreground>\r\n                            </Label>\r\n         " +
                "                   <Label Content=\"TO\"\r\n                             " +
                "   Margin=\"41,0,0,0\"\r\n                           " +
                "    FontSize=\"14\"\r\n                            " +
                "   FontWeight=\"Bold\" Background=\"White\" \r\n        " +
                "                       >\r\n                        " +
                "        <Label.Foreground>\r\n                " +
                "                    <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n     " +
                "                                   <GradientStop Color=\"#FF00FF04\"/>\r\n               " +
                "" +
                "                         <GradientStop Color=\"#FF110040\" Offset=\"1\"/>\r\n       " +
                "                             </LinearGradientBrush>\r\n                      " +
                "          </Label.Foreground>\r\n                            </Label>\r\n            " +
                "                <Label Content=\""+TO+"\"\r\n                              " +
                "  Margin=\"47,0,0,0\"\r\n                               FontSize=\"14\"\r\n    " +
                "                           FontWeight=\"Bold\" Background=\"White\" \r\n        " +
                "                       >\r\n                                <Label.Foreground>\r\n       " +
                "                             <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n           " +
                "                             <GradientStop Color=\"#FF2A2D58\"/>\r\n               " +
                "                         <GradientStop Color=\"#FF110040\" Offset=\"1\"/>\r\n       " +
                "" +
                "                             </LinearGradientBrush>\r\n                         " +
                "" +
                "       </Label.Foreground>\r\n                            </Label>\r\n           " +
                "             </StackPanel>\r\n                        <Label Content=\""+FROMTIME+"\"\r\n  " +
                "                              Margin=\"0,-58,280,0\"\r\n                          " +
                "     FontSize=\"9\"\r\n                                   Height=\"20\"\r\n         " +
                "                      FontWeight=\"Bold\" \r\n                               " +
                "    Width=\"100\"\r\n                               >\r\n                     " +
                "       <Label.Foreground>\r\n                          " +
                "      <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n    " +
                "                                <GradientStop Color=\"#FF2B00FF\"/>\r\n    " +
                "                                <GradientStop Color=\"#FF110040\" Offset=\"1\"/>\r\n      " +
                "                          </LinearGradientBrush>\r\n                        " +
                "    </Label.Foreground>\r\n                        </Label>\r\n              " +
                "          <Label Content=\"ARRIVE\"\r\n                        " +
                "        Margin=\"-274.5,-32,0,0\"\r\n                       " +
                "        FontSize=\"14\"\r\n                           " +
                "       \r\n                               FontWeight=\"Bold\" \r\n        " +
                "                           Width=\"100\" Height=\"25\" Background=\"Transparent\"\r\n            " +
                "" +
                "                   >\r\n                            <Label.Foreground>\r\n                    " +
                "            <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n             " +
                "                       <GradientStop Color=\"#FF00FF04\"/>\r\n                    " +
                "                <GradientStop Color=\"#FF110040\" Offset=\"1\"/>\r\n            " +
                "                    </LinearGradientBrush>\r\n           " +
                "                 </Label.Foreground>\r\n               " +
                "         </Label>\r\n                        <Label Content=\""+TOTIME+"\"\r\n     " +
                "                           Margin=\"0,-8,280,0\"\r\n                        " +
                "       FontSize=\"9\"\r\n                                   Height=\"20\"\r\n   " +
                "                            FontWeight=\"Bold\" \r\n                         " +
                "          Width=\"100\"\r\n                               >\r\n            " +
                "                <Label.Foreground>\r\n                              " +
                "  <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n      " +
                "                              <GradientStop Color=\"#FF2B00FF\"/>\r\n        " +
                "                            <GradientStop Color=\"#FF110040\" Offset=\"1\"/>\r\n    " +
                "                            </LinearGradientBrush>\r\n                   " +
                "         </Label.Foreground>\r\n                        </Label>\r\n            " +
                "        </StackPanel>\r\n\r\n\r\n\r\n                    <StackPanel>\r\n       " +
                "                 <Border Margin=\"0,0,140,0\" CornerRadius=\"0,59,0,9\" Height=\"30\" Width=\"234\" >\r\n    " +
                "                        <Border.Background>\r\n                        " +
                "        <LinearGradientBrush EndPoint=\"0.5,1\" StartPoint=\"0.5,0\">\r\n           " +
                "                         <GradientStop Color=\"#FF00C71E\"/>\r\n                " +
                "                    <GradientStop Color=\"#FFC000C7\" Offset=\"1\"/>\r\n        " +
                "                        </LinearGradientBrush>\r\n                       " +
                "     </Border.Background>\r\n                            <Label Content=\"BUS COMPANY\"\r\n             " +
                "                  Foreground=\"White\"\r\n                                Margin=\"10,0,0,0\"\r\n      " +

                "                         FontSize=\"17\"\r\n                               FontWeight=\"Bold\" \r\n                               />\r\n                 " +
                "       </Border>\r\n                        <Border Width=\"56\" Height=\"56\"\r\n                                Margin=\"310,-62,0,0\"\r\n                      " +
                "          CornerRadius=\"40\" Background=\"#FFAFAF4D\">\r\n                            <StackPanel>\r\n    " +
                "                            <Label Margin=\"7,0,0,28\" Content=\"SEAT\" FontWeight=\"DemiBold\" FontSize=\"14\" Foreground=\"White\"/>\r\n                    " +

                "            <Label Margin=\"0,-40,0,0\" Content=\"87\" HorizontalContentAlignment=\"Center\" FontWeight=\"DemiBold\" FontSize=\"14\" Foreground=\"White\" Height=\"29\"/>\r\n             " +
                "               </StackPanel>\r\n                        </Border>\r\n         " +
                "           </StackPanel>\r\n                </StackPanel>\r\n            </Border>\r\n   " +
                "     </StackPanel>\r\n    </Grid>";
            Grid Template = (Grid)XamlReader.Parse(xaml);
            Template.HorizontalAlignment = HorizontalAlignment.Center;
            tic.Children.Add(Template);
           
        }
        public void uploadData()
        {

            Highlights.Children.Clear();
            // display scheduled buses from database

            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand("select BUS_FROM,DEPATURE_TIME,BUS_TO,ARRIVE_TIME,Price from BUS_SCHEDULES order by DEPATURE_TIME Asc", conn);
                SqlDataReader reader = command.ExecuteReader();

               while (reader.Read())
                {
                    displaydata(reader.GetString(0).ToUpper(), reader.GetString(1).ToUpper(), reader.GetString(2).ToUpper(), reader.GetString(3).ToUpper(), reader.GetString(4).ToUpper());
                }

                conn.Close();

            }
            catch
            {
                MessageBox.Show("no!");
            }

        }
        public void Error()
        {
            string xaml = @"
    <Grid xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' Margin=""0,10,0,0"" >
        <Border CornerRadius=""19"" 
                 BorderBrush=""#99274D""
                BorderThickness=""2""
                Background=""White"">
            <StackPanel>
                <TextBlock Text=""We Cannot Find Buses For Entered Entries""
                           FontWeight=""Bold""
                           FontSize=""17""
                           Margin=""0,6,0,0""
                           HorizontalAlignment=""Center""
                           />
                <Button VerticalAlignment=""Bottom"" HorizontalAlignment=""Right"" Margin=""0,20,10,0"">
                    <Button.Style>
                        <Style TargetType=""Button"">
                            <Setter Property=""Width"" Value=""60""/>
                            <Setter Property=""FontSize"" Value=""17""/>
                            <Setter Property=""FontWeight"" Value=""Bold""/>
                            <Setter Property=""Foreground"" Value=""White""/>
                            <Setter Property=""Height"" Value=""24""/>
                            <Setter Property=""Background"" Value=""#FF4FCC0B""/>
                            <Setter Property=""BorderThickness"" Value=""0""/>
                            <Style.Triggers>
                                <Trigger Property=""IsMouseOver"" Value=""True"">
                                    <Setter Property=""Background"" Value=""#692EC4""/>
                                </Trigger>
                            </Style.Triggers>
                        </Style>
                        
                    </Button.Style>
                    <Button.Template>
                        <ControlTemplate TargetType=""Button"">
                            <Border Background=""{TemplateBinding Background}"" CornerRadius=""9"">
                                <ContentPresenter Content=""OK"" VerticalAlignment=""Center""
                                                  HorizontalAlignment=""Center""/>
                            </Border>
                        </ControlTemplate>
                    </Button.Template>
                </Button>
            </StackPanel>
        </Border>
    </Grid>
";
            Grid Template = (Grid)XamlReader.Parse(xaml);
            Window win = new Window {
                Width = 400,
                Height = 90,
                AllowsTransparency = true,
                WindowStyle = WindowStyle.None,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                Background = new SolidColorBrush(Colors.Transparent),
                
            };

            Button contentPresenter = FindVisualChild<Button>(Template);
            if (contentPresenter != null)
            {
                contentPresenter.Click += pop_close;
            }
                win.Content = Template;
            win.Show();
        }
        public DashboardView()
        {
            InitializeComponent();
            Clear();
            /*   conn.Open();
               string queryString1 = "select count(*) from BUS_SCHEDULES";
               SqlCommand command1 = new SqlCommand(queryString1, conn);
               int count = (int)command1.ExecuteScalar();
               active.Text = string.Empty;
               active.Text = count.ToString();

           *//*    conn.Close();
   */       try
            {
                active.Text = File.ReadAllText("act.txt");
            }
            catch
            {

            };

/*            it.Children.Clear();*/
            file.Text=File.ReadAllText("" + File.ReadAllText("name.txt") + ".txt").ToString();
            currentUser.Text = File.ReadAllText("name.txt").ToString();
            currentuserEmail.Text = File.ReadAllText("email.txt").ToString();
            it.Margin = new Thickness(2000);
            log.Margin = new Thickness(2444, 178, 10, -456);
            Pay.Margin = new Thickness(2444, 178, 10, -456);
            xc.Children.Remove(cx);
           ds.Text=DateTime.Now.ToShortDateString();
            File.WriteAllText("Date.txt",ds.Text);
            LoginView login = new LoginView();
            DataContext = this;
            toContent = "DESTINATION";
          
            searchfrom.Text = "Search Bus From..";
            searchTo.Text = "Search Bus To..";
            Highlights.Children.Clear();
            // display scheduled buses from database
            Num = 1;

            Container.Margin = new Thickness(244, 178, 10, -456);
            it.Margin = new Thickness(2000);
            log.Margin = new Thickness(2444, 178, 10, -456);
            Pay.Margin = new Thickness(2444, 178, 10, -456);
            Final.Margin = new Thickness(2444, 178, 10, -456);
            Container.VerticalScrollBarVisibility = ScrollBarVisibility.Visible;
            Highlights.Children.Clear();
            uploadData();

            datedisplay.Text = DateTime.Now.ToShortDateString();

            conn.Open();
            SqlCommand command = new SqlCommand("select Dat_e,From_T ,To_T,Ticket_Id ,Price from History where Names='" + currentUser.Text.ToString() + "'", conn);
            SqlDataReader read = command.ExecuteReader();

            while (read.Read())
            {
                myrev(read.GetString(0), read.GetString(1).ToUpper(), read.GetString(2).ToUpper(), read.GetString(3).ToUpper(), read.GetString(4).ToUpper());
            }

            conn.Close();

        
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            //move  window
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }

        }
        private void Window_Mouseown(object sender, MouseButtonEventArgs e)
        {
            //move  window
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                Window window = Window.GetWindow(sender as Button);

                if (window != null)
                {
                    if (e.LeftButton == MouseButtonState.Pressed)
                    {
                        DragMove();
                    }
                }
            }

        }

        public void btnMinimize_click(object sender, RoutedEventArgs e)
        {
            //minimize the window
            WindowState = WindowState.Minimized;

        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            //close
            System.Diagnostics.Process.GetCurrentProcess().Kill();

            System.Windows.Application.Current.Shutdown();

        }


        private void btnMyTickets_Click(object sender, RoutedEventArgs e)
        {
            //CREATE TICKET
            parent.Children.Clear();
            set.Margin = new Thickness(2000);
            Container.Margin = new Thickness(3000);
            it.Margin = new Thickness(244, 178, 10, -456);
            log.Margin = new Thickness(2444, 178, 10, -456);
            tic.Margin = new Thickness(2444, 178, 10, -456);
            Pay.Margin = new Thickness(2444, 178, 10, -456);
            Final.Margin = new Thickness(2444, 178, 10, -456);
            conn.Open();
            SqlCommand command = new SqlCommand("select Dat_e,From_T ,To_T,Ticket_Id ,Price from History where Names='" + currentUser.Text.ToString() + "'", conn);
            SqlDataReader read = command.ExecuteReader();

            while (read.Read())
            {
                myrev(read.GetString(0), read.GetString(1).ToUpper(), read.GetString(2).ToUpper(), read.GetString(3).ToUpper(), read.GetString(4).ToUpper());
            }

            conn.Close();

        }

        private void btnhome_Click(object sender, RoutedEventArgs e)
        {
            //home option
            Container.Margin = new Thickness(244, 178, 10, -456);
            it.Margin = new Thickness(2000);
            set.Margin = new Thickness(2000);
            log.Margin = new Thickness(2444, 178, 10, -456);
            Pay.Margin = new Thickness(2444, 178, 10, -456);
            tic.Margin = new Thickness(2444, 178, 10, -456);
            Final.Margin = new Thickness(2444, 178, 10, -456);
            Container.VerticalScrollBarVisibility = ScrollBarVisibility.Visible;
            Highlights.Children.Clear();
            uploadData();
        
        }
        private void pop_close(object sender, RoutedEventArgs e)
        {


            Window window = Window.GetWindow(sender as Button);
            window.Close();
            uploadData();
            Container.VerticalScrollBarVisibility= ScrollBarVisibility.Visible;
        }
        //increase passenger
        private void addone(object sender, RoutedEventArgs e)
        {
            Num++;
          
            Button button = sender as Button;

            StackPanel parent = button.Parent as StackPanel;
            Border Box = parent.Children[1] as Border;
            TextBlock textBlock = Box.Child as TextBlock;
            textBlock.Text= Num.ToString();
             StackPanel stack = Box.Parent as StackPanel;
            Border stack2 = stack.Parent as Border;
            StackPanel stack3 = stack2.Parent as StackPanel;
            Border stack4 = stack3.Children[1] as Border;
            StackPanel stack5 = stack4.Child as StackPanel;
            Border stack6 = stack5.Children[1] as Border;
            TextBlock textBlock1 = stack6.Child as TextBlock;


            string num = File.ReadAllText("Const.txt").ToString().Trim('P', 'p');
           /* textBlock1.Text = num.ToString();
            double price = double.Parse(num) * Num;
            double con = price / Num;
            string cost = "P" + price.ToString() + ".00";
            textBlock1.Text = cost.ToString();*/

        }
        private void removeone(object sender, RoutedEventArgs e)
        {
            Num--;
            if (Num < 1)
            {
                Num= 1;
            }
            Button button = sender as Button;

            StackPanel parent = button.Parent as StackPanel;
            Border Box = parent.Children[1] as Border;
            TextBlock textBlock = Box.Child as TextBlock;
            textBlock.Text = Num.ToString();
            StackPanel stack = Box.Parent as StackPanel;
            Border stack2 = stack.Parent as Border;
            StackPanel stack3 = stack2.Parent as StackPanel;
            Border stack4 = stack3.Children[1] as Border;
            StackPanel stack5 = stack4.Child as StackPanel;
            Border stack6 = stack5.Children[1] as Border;
            TextBlock textBlock1 = stack6.Child as TextBlock;


            string num = File.ReadAllText("Const.txt").ToString().Trim('P', 'p');
           /* textBlock1.Text = num.ToString();
            double prie = double.Parse(num);
            double price = double.Parse(num) * Num;
            if(price < prie ) price = prie;
            double con = price / Num;
            string cost = "P" + price.ToString() + ".00";
         *//*   textBlock1.Text = cost.ToString();*/

        }

        private void BOOK01_Click(object sender, RoutedEventArgs e)
        {
            var date = DateTime.Now;
            Button button = sender as Button;
            if (button != null)
            {
                StackPanel stack1 = button.Parent as StackPanel;
                if (stack1 != null)
                {
                    StackPanel stack2 = stack1.Parent as StackPanel;
                    {
                        StackPanel stack4 = stack2.Children[1] as StackPanel;
                        StackPanel stack5 = stack4.Children[0] as StackPanel;
                        Grid stack6 = stack5.Children[0] as Grid;
                        TextBlock fro = stack6.Children[0] as TextBlock;
                        TextBlock frotime = stack6.Children[1] as TextBlock;
                        TextBlock tod = stack6.Children[2] as TextBlock;
                        TextBlock toTimed = stack6.Children[3] as TextBlock;
                        TextBlock cost = stack1.Children[0] as TextBlock;
                        confirm(fro.Text, frotime.Text, tod.Text, toTimed.Text,cost.Text,date.ToShortDateString());
                        conn.Open();
                        SqlCommand command = new SqlCommand("select Dat_e,From_T ,To_T,Ticket_Id ,Price from History where Names='" + currentUser.Text.ToString() + "'", conn);
                        SqlDataReader read = command.ExecuteReader();

                        while (read.Read())
                        {
                            myrev(read.GetString(0), read.GetString(1).ToUpper(), read.GetString(2).ToUpper(), read.GetString(3).ToUpper(), read.GetString(4).ToUpper());
                        }

                        conn.Close();


                    }
                }
            }



        }
        //corfirm ticket
        private void Confirm(object sender, RoutedEventArgs e)
        {
            Container.Margin = new Thickness(3000);
            it.Margin = new Thickness(2444, 178, 10, -456);
            log.Margin = new Thickness(2444, 178, 10, -456);
           Pay.Margin = new Thickness(340, 196, 154, -364);
            tic.Margin = new Thickness(0,78,0,0);
            //CREATE TICKET
            Window window = Window.GetWindow(sender as Button);

            Container.VerticalScrollBarVisibility = ScrollBarVisibility.Hidden;
            Highlights.Children.Clear();

            window.Close();
            string Data = File.ReadAllText("name.txt");
            string Data2 = File.ReadAllText("email.txt");

            Button button = sender as Button;
            StackPanel stackPanel = button.Parent as StackPanel;
            StackPanel stackPanel1 = stackPanel.Parent as StackPanel;
            StackPanel stack1 = stackPanel1.Children[3] as StackPanel;
            TextBlock fro = stack1.Children[0] as TextBlock;
            TextBlock tod = stack1.Children[1] as TextBlock;
            StackPanel stack2 = stackPanel1.Children[5] as StackPanel;
            TextBlock frotime = stack2.Children[0] as TextBlock;
            TextBlock toTimed = stack2.Children[1] as TextBlock;
            // ticket id
            Random random = new Random();
            int ranf = random.Next(100000, 999991);
            var date = DateTime.Now;
            CreateTicket(fro.Text, frotime.Text, tod.Text, toTimed.Text, ranf.ToString());
            f7.Text=ranf.ToString();
            conn.Open();
            SqlCommand comm = conn.CreateCommand();
            comm.CommandType = CommandType.Text;
            comm.CommandText = "insert into History values('" + fro.Text + "','" + frotime.Text + "','" + tod.Text + "','" + toTimed.Text + "','" + ranf.ToString() + "','" + "P" + File.ReadAllText("Price.txt").ToString().ToUpper() + ".00" + "','" + Data + "','" + Data2 + "','" + File.ReadAllText("Date.txt").ToString() + "')";
            comm.ExecuteNonQuery();
            conn.Close();
            
            if (active.Text==" " || active.Text== string.Empty)
            {
                active.Text = "0";
            }
            string can = active.Text.ToString();
            int x = int.Parse(can);
            x += 1;
            active.Text = x.ToString();
            File.WriteAllText("act.txt", x.ToString());
            File.AppendAllText("" + File.ReadAllText("name.txt") + ".txt", "Reservation from " + fro.Text + " to " + tod.Text + " was corfirmed at " + date.ToString() + Environment.NewLine);
            file.Text = File.ReadAllText("" + File.ReadAllText("name.txt") + ".txt").ToString();
            restart();
        }

        public void Clear()
        {

            /* currentuserEmail.Text = "";
             currentUser.Text = "";*/
        }
        //search section
        private void searchfrom_LostFocus(object sender, RoutedEventArgs e)
        {
            if (searchfrom.Text == "")
            {
                searchfrom.Text = "Search Bus From..";
            }

        }

        private void searchfrom_GotFocus(object sender, RoutedEventArgs e)
        {
            if (searchfrom.Text == "Search Bus From..")
            {
                searchfrom.Text = string.Empty;
            }

        }

        private void searchTo_LostFocus(object sender, RoutedEventArgs e)
        {
            if (searchTo.Text == "")
            {
                searchTo.Text = "Search Bus To..";
            }

        }

        private void searchTo_GotFocus(object sender, RoutedEventArgs e)
        {
            if (searchTo.Text == "Search Bus To..")
            {
                searchTo.Text = string.Empty;
            }

        }



        private void calendershow_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            string selected_date = calendershow.SelectedDate.ToString();


            datedisplay.Text = selected_date.Trim('0', ':');
            

        }

        private void btnSettings_Click(object sender, RoutedEventArgs e)
        {
            Pay.Margin = new Thickness(2444, 178, 10, -456);
            Final.Margin = new Thickness(2444, 178, 10, -456);
            /*  Error();*/
            tic.Margin = new Thickness(2444, 178, 10, -456);
            log.Margin = new Thickness(2444, 1788, 10, -456);
            set.Margin = new Thickness(230, 155, 2, -602);
            it.Margin = new Thickness(2444, 178, 10, -456);
            Container.Margin = new Thickness(3000);
            restart();
        }

        public void restart()
        {
            InitializeComponent();
        }

        //select time 


        private void SEARCHBUS_Click(object sender, RoutedEventArgs e)
        {
            //quiring db

            set.Margin = new Thickness(2000);
            it.Margin = new Thickness(2444, 178, 10, -456);
            log.Margin = new Thickness(2444, 178, 10, -456);
            set.Margin = new Thickness(7000);
            Container.Margin = new Thickness(244, 178, 10, -456);
            if (searchfrom.Text != "Search Bus From..")
            {
                conn.Open();

                SqlCommand search = conn.CreateCommand();
                search.CommandType = CommandType.Text;
                search.CommandText = "select BUS_FROM,DEPATURE_TIME,BUS_TO,ARRIVE_TIME,Price from BUS_SCHEDULES where BUS_FROM='" + searchfrom.Text.ToLower() + "' order by DEPATURE_TIME Asc";

                SqlDataReader reader = search.ExecuteReader();
                if (reader.Read())
                {
                    Highlights.Children.Clear(); displaydata(reader.GetString(0).ToUpper(), reader.GetString(1).ToUpper(), reader.GetString(2).ToUpper(), reader.GetString(3).ToUpper(), reader.GetString(4).ToUpper()); 
                    
                }
                else
                {
                    Error();
                }
                conn.Close();
            }
            else if (searchTo.Text != "Search Bus To..")
            {
                conn.Open();

                SqlCommand search = conn.CreateCommand();
                search.CommandType = CommandType.Text;
                search.CommandText = "select BUS_FROM,DEPATURE_TIME,BUS_TO,ARRIVE_TIME,Price from BUS_SCHEDULES where BUS_TO='" + searchTo.Text.ToLower() + "' order by DEPATURE_TIME Asc";

                SqlDataReader reader = search.ExecuteReader();
                if (reader.Read())
                {
                    Highlights.Children.Clear();
                    displaydata(reader.GetString(0).ToUpper(), reader.GetString(1).ToUpper(), reader.GetString(2).ToUpper(), reader.GetString(3).ToUpper(), reader.GetString(4).ToUpper());
                }
                else
                {
                    Error();
                }
                conn.Close();
            }
            else if(searchTo.Text != "Search Bus To.." && searchfrom.Text != "Search Bus From..")
            {
                conn.Open();

                SqlCommand search = conn.CreateCommand();
                search.CommandType = CommandType.Text;
                search.CommandText = "select BUS_FROM,DEPATURE_TIME,BUS_TO,ARRIVE_TIME,Price from BUS_SCHEDULES  where BUS_TO='" + searchTo.Text.ToLower() + "' And BUS_TO='" + searchTo.Text.ToLower() + "' order by DEPATURE_TIME Asc ";

                SqlDataReader reader = search.ExecuteReader();
                if (reader.Read())
                {
                    Highlights.Children.Clear();
                    displaydata(reader.GetString(0).ToUpper(), reader.GetString(1).ToUpper(), reader.GetString(2).ToUpper(), reader.GetString(3).ToUpper(), reader.GetString(4).ToUpper());
                }
                else
                {
                    Error();
                }


                conn.Close();
            }
           
            


        }

        private void btnViewSchedule_Click(object sender, RoutedEventArgs e)
        {
            Container.Margin = new Thickness(3000);
            Final.Margin = new Thickness(2444, 178, 10, -456);
            set.Margin = new Thickness(2000);
            it.Margin = new Thickness(2444, 178, 10, -456);
            log.Margin = new Thickness(244, 178, 10, -456);
            
        }

        private void options_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            StackPanel stack = btn.Parent as StackPanel;
            TextBlock id = stack.Children[3] as TextBlock;
            File.WriteAllText("id.txt",id.Text);
            win();
              
            
        }
        private void yess(object sender, RoutedEventArgs e)
        {
            conn.Open();
            SqlCommand sql = new SqlCommand("delete from History Where Ticket_Id='" + File.ReadAllText("id.txt") + "'",conn);
           sql.ExecuteNonQuery();
            var date = DateTime.Now;
            conn.Close();
            Window window = Window.GetWindow(sender as Button);
            window.Close();

            string can = active.Text.ToString();
            int x = int.Parse(can);
            x--;
            if(x < 0){
                x = 0;
            }
            File.WriteAllText("act.txt", x.ToString());
            active.Text = x.ToString();
            File.AppendAllText("" + File.ReadAllText("name.txt") + ".txt", "Reservation  ticket id "+ File.ReadAllText("id.txt") + "  was cancelled at " + date.ToString() + Environment.NewLine);
            file.Text = File.ReadAllText("" + File.ReadAllText("name.txt") + ".txt").ToString();
            refresh();
        }
      
        public void win()
        {
          
            Window win = new Window
            {
                AllowsTransparency = true,
                WindowStyle = WindowStyle.None,
                Background = new SolidColorBrush(Colors.Transparent),
                Width = 250,
                Height = 100,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ShowInTaskbar = false,
            };

            Border border = new Border
            {
               /* Background = new SolidColorBrush(Colors.Beige),*/
               Background=jus.Background,
                CornerRadius = new CornerRadius(9),
                Effect = ole.Effect,
            };
            StackPanel panel = new StackPanel
            {
            
            };
            StackPanel panel2 = new StackPanel
            {
                Orientation = cx.Orientation,
                Margin = cx.Margin,
            };
            Button yep = new Button {
                Foreground=yes.Foreground, Background=yes.Background,
                Margin=yes.Margin,FontWeight=yes.FontWeight,
                

            };
            yep.Template = yes.Template;
            Button nop = new Button
            {
                Foreground = no.Foreground,
                Background = no.Background,
                Margin = no.Margin,
                FontWeight = no.FontWeight,


            };
            nop.Template = no.Template;
            panel2.Children.Add( yep );
            panel2.Children.Add(nop);
            TextBlock text1 = new TextBlock
            {
                Foreground = no.Foreground,
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Text = "Cancel the reservation?",

                VerticalAlignment = VerticalAlignment.Top,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(10),
            };
            nop.Click += pop_close;
            yep.Click += yess;
            panel.Children.Add(text1);
            panel.Children.Add(panel2);
            border.Child = panel;
            win.Content = border;
            win.Show();
          
        }

        public void myrev(string date,string From,string DES,string t_id,string price)
        {
            Border bd = new Border { 
                Background=BD.Background,
                Width=BD.Width,Height=BD.Height,
                Margin=BD.Margin,VerticalAlignment=BD.VerticalAlignment,CornerRadius=BD.CornerRadius,
            };
            StackPanel pan = new StackPanel {
                Orientation=Orientation.Horizontal,
            };

            TextBlock T1 = new TextBlock { 
                Foreground=t1.Foreground,Margin=t1.Margin,FontSize=t1.FontSize,Width=t1.Width,Height=t1.Height,VerticalAlignment=t1.VerticalAlignment,
                Text=date,FontWeight=FontWeights.Bold,
            };
            TextBlock T2 = new TextBlock
            {
                Foreground = t2.Foreground,
                Margin = t2.Margin,
                FontSize = t2.FontSize,
                Width = t2.Width,
                Height = t2.Height,
                VerticalAlignment = t2.VerticalAlignment,
                Text = From,
                FontWeight = FontWeights.Bold,
            };
            TextBlock T3 = new TextBlock
            {
                Foreground = t2.Foreground,
                Margin = t3.Margin,
                FontSize = t1.FontSize,
                Width = t3.Width,
                Height = t3.Height,
                VerticalAlignment = t1.VerticalAlignment,
                Text = DES,
                FontWeight = FontWeights.Bold,
            };
            TextBlock T4 = new TextBlock
            {
                Foreground = t1.Foreground,
                Margin = t4.Margin,
                FontSize = t1.FontSize,
                Width = t4.Width,
                Height = t1.Height,
                VerticalAlignment = t1.VerticalAlignment,
                Text = t_id,
                FontWeight = FontWeights.Bold,
            };
            TextBlock T5 = new TextBlock
            {
                Foreground = t1.Foreground,
                Margin = t5.Margin,
                FontSize = t1.FontSize,
                Width = t5.Width,
                Height = t1.Height,
                VerticalAlignment = t1.VerticalAlignment,
                Text = price,
                FontWeight = FontWeights.Bold,
            };
            Button btn = new Button();
            btn.Template = options.Template;
            btn.Click += options_Click;
            pan.Children.Add(T1);
            pan.Children.Add(T2);
            pan.Children.Add(T3);
            pan.Children.Add(T4);
            pan.Children.Add(T5);
            pan.Children.Add(btn);
            bd.Child= pan;
            parent.Children.Add (bd);
        }

        public void refresh()
        {
            parent.Children.Clear();
            conn.Open();
            SqlCommand command = new SqlCommand("select Dat_e,From_T ,To_T,Ticket_Id ,Price from History where Names='" + currentUser.Text.ToString() + "'", conn);
            SqlDataReader read = command.ExecuteReader();

            while (read.Read())
            {
                myrev(read.GetString(0), read.GetString(1).ToUpper(), read.GetString(2).ToUpper(), read.GetString(3).ToUpper(), read.GetString(4).ToUpper());
            }

            conn.Close();
        }

        private void searchTo_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void pay_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ticket Bought");
            Pay.Margin = new Thickness(2444, 178, 10, -456);
            Final.Margin = new Thickness(230, 155, 2, -602);
        }
    }
}