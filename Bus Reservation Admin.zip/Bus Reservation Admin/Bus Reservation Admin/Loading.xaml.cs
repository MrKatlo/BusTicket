﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Bus_Reservation_Admin
{
    /// <summary>
    /// Interaction logic for Loading.xaml
    /// </summary>
   /* public partial class Loading : Window,INotifyPropertyChanged
    {

        private BackgroundWorker vorker = new BackgroundWorker();
        private int _workerstate;



        public int workerstate
        {
            get { return _workerstate; }
            set
            {
                _workerstate = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("workerstate"));
            }
        }

        public Loading()
        {
            InitializeComponent();
            DataContext = this;


            vorker.DoWork += (s, e) =>
            {
                for (int i = 0; i <= 100; i += 1)
                {
                    System.Threading.Thread.Sleep(100);

                    workerstate = i;




                }
                MessageBox.Show("sas");
              *//*  this.Close();
              MainWindow main= new MainWindow();
                main.Show();*//*
            };
            vorker.RunWorkerAsync();
        }

        #region INotifyPropertyChanged Member

        public event PropertyChangedEventHandler PropertyChanged;
        #endregion  
    }*/
}
    

