﻿Select * from Employees
