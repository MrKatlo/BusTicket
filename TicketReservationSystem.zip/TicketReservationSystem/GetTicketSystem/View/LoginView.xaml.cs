﻿using System.Windows;
using System.Windows.Input;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Media;
using System;

namespace GetTicketSystem.View
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    /// 
    public static class SharedData  
    {
        public static string MyData { get; set; }
    }
   
    public partial class LoginView : Window
    {


       SqlConnection sql = new SqlConnection(@"Data Source=DESKTOP-GEIT3P6;Initial Catalog=GetTicketSystem;Integrated Security=True");
        SqlDataReader reader;
        SqlCommand bash;
        SqlCommand bash1;
        public LoginView()
        {
            InitializeComponent();
          
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        public void btnMinimize_click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        public void btnRegister_Click(object sender, RoutedEventArgs e)
        {
           
            RegisterView register=new RegisterView();
          
            register.Show();
            this.Close();


        }
        public void btnForgetPassword_Click(object sender, RoutedEventArgs e)
        {

            ResetPasswordView passwordView = new ResetPasswordView();
             passwordView.Show();
            this.Close();
         

        }

        public void btnlogin_click(object sender, RoutedEventArgs e)
        {
            var date= DateTime.Now;
            sql.Open();
            bash= new SqlCommand("select * from Customers where Email=@Email and Password=@Password",sql);
            bash.Parameters.AddWithValue("@Email", txtEmail.Text);
            bash.Parameters.AddWithValue("@Password", txtPassword.Password);
            reader=bash.ExecuteReader();
            if(reader.HasRows)
            {
               
                 File.WriteAllText("email.txt",txtEmail.Text.ToString());
              
                DashboardView dashboardView = new DashboardView();
                sql.Close();

                sql.Open();
                bash = new SqlCommand("select * from Customers where Email=@Email and Password=@Password", sql);
                bash.Parameters.AddWithValue("@Email", txtEmail.Text);
                bash.Parameters.AddWithValue("@Password", txtPassword.Password);
                reader = bash.ExecuteReader();
                while (reader.Read())
                {
                    File.WriteAllText("name.txt", reader.GetString(1).ToString() + " " + reader.GetString(2).ToString());   
                    File.AppendAllText("" + File.ReadAllText("name.txt") + ".txt", "Log-in sucesss at "+date.ToString()+ Environment.NewLine);
                }
                sql.Close();
                dashboardView.Show();
            this.Close();
               
            }
            else
            {
                Warning.Text = "Something Is Wrong!";
                Warning.Foreground= new SolidColorBrush(Colors.Red);
               
            }
          
           
        }

        public string CurrentUser()
        {
            return txtEmail.Text;
        }

    

        private void txtPassword_GotFocus(object sender, RoutedEventArgs e)
        {
           
        }

      

        private void txtPassword_LostFocus(object sender, RoutedEventArgs e)
        {
            Warning.Text = "Login By Entering Your Info";
            
        }

        private void txtEmail_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void txtEmail_KeyUp(object sender, KeyEventArgs e)
        {
         
        }
    }
}
