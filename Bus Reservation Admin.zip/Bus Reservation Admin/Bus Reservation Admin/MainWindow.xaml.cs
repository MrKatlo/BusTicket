﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Diagnostics;
using System.Collections;

namespace Bus_Reservation_Admin
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int change =0;
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-GEIT3P6;Initial Catalog=GetTicketSystem;Integrated Security=True");
        double totalmoney;
        public MainWindow()
        {
            InitializeComponent();
            parent.Children.Remove(BD);
            names.Children.Remove(names.Children[1]);
            emai.Children.Remove(emai.Children[1]);
            from.Children.Remove(from.Children[1]);
            dest.Children.Remove(dest.Children[1]);
            paid.Children.Remove(paid.Children[1]);
            dest.Children.Remove(total);
            paid.Children.Remove(cash1);
            conn.Open();
            
            string queryString1 = "select count(*) from BUS_SCHEDULES";
            SqlCommand command1 = new SqlCommand(queryString1, conn);
            int count = (int)command1.ExecuteScalar();
            num.Text = string.Empty;
            num.Text = count.ToString();

            conn.Close();


            conn.Open();
            string queryString2 = "select count(*) from History";
            SqlCommand command2 = new SqlCommand(queryString2, conn);
            int count2 = (int)command2.ExecuteScalar();
            num2.Text= string.Empty;
            num2.Text = count2.ToString();

            conn.Close();

            conn.Open();
            SqlCommand command = new SqlCommand("select  From_T,To_T,Ticket_Id,Price,Names,email from History", conn);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {   
                string cash = reader.GetString(3).ToString().Trim('P');
                
                double ash= double.Parse(cash);
                totalmoney += ash;
               
               
               
                addname(reader.GetString(4).ToString());
                addemail(reader.GetString(5));
                addfrom(reader.GetString(0).ToString());
                addto(reader.GetString(1).ToString());
                addprice(reader.GetString(3).ToString());
                Border bd = new Border
                {
                   Background=BD.Background,Height= BD.Height,Width= BD.Width,CornerRadius=BD.CornerRadius,VerticalAlignment=BD.VerticalAlignment,Margin=BD.Margin
                };
                StackPanel stack = new StackPanel { 
                    Orientation= Orientation.Horizontal,
                };
                TextBlock name = new TextBlock
                {
                   Height=t1.Height,Width=t1.Width,
                    Foreground=t1.Foreground,
                    FontWeight=t1.FontWeight,
                    VerticalAlignment=t1.VerticalAlignment,Margin=t1.Margin,
                    FontSize=t1.FontSize,
                    Text = reader.GetString(4)

                };
                TextBlock from = new TextBlock
                {
                    Height = t2.Height,
                    Width = t2.Width,
                    Foreground = t2.Foreground,
                    FontWeight = t2.FontWeight,
                    VerticalAlignment = t2.VerticalAlignment,
                    Margin = t2.Margin,
                    FontSize = t1.FontSize,
                    Text = reader.GetString(0)
                    
                };
                TextBlock to = new TextBlock
                {
                    Height = t3.Height,
                    Width = t3.Width,
                    Foreground = t3.Foreground,
                    FontWeight = t3.FontWeight,
                    VerticalAlignment = t3.VerticalAlignment,
                    Margin = t3.Margin,
                    FontSize = t3.FontSize,
                    Text = reader.GetString(1)
                };
                TextBlock qnt = new TextBlock
                {
                    Height = t4.Height,
                    Width = t4.Width,
                    Foreground = t4.Foreground,
                    FontWeight = t4.FontWeight,
                    VerticalAlignment = t4.VerticalAlignment,
                    Margin = t4.Margin,
                    FontSize = t4.FontSize,
                    Text = reader.GetString(2)
                };
                TextBlock price = new TextBlock
                {
                    Height = t5.Height,
                    Width = t5.Width,
                    Foreground = t5.Foreground,
                    FontWeight = t5.FontWeight,
                    VerticalAlignment = t5.VerticalAlignment,
                    Margin = t5.Margin,
                    FontSize = t5.FontSize,
                    Text = reader.GetString(3)
                };  
                stack.Children.Add(name);
                stack.Children.Add(from);
                stack.Children.Add(to);
                stack.Children.Add(qnt);
                stack.Children.Add(price);
                bd.Child= stack;
                parent.Children.Add(bd);
                txtcash.Text = "P"+totalmoney.ToString()+".00";
            }
            dest.Children.Add(total);
            paid.Children.Add(cash1);
            
            conn.Close();
        }

        public void addname(string content)
        {
            Border border = new Border
            {
                BorderBrush = pbd.BorderBrush,
                BorderThickness = pbd.BorderThickness,
            };
            border.Style = pbd.Style;
            TextBlock text = new TextBlock
            {
                Background = txt.Background,
                FontSize = txt.FontSize,
                FontWeight = txt.FontWeight,
                Foreground = txt.Foreground,
                TextAlignment = TextAlignment.Center,
                Text=content
            };

            border.Child = text;
            names.Children.Add(border); 
            
        }
        public void addemail(string content)
        {
            Border border = new Border
            {
                BorderBrush = pbd.BorderBrush,
                BorderThickness = pbd.BorderThickness,
            };
            border.Style = pbd.Style;
            TextBlock text = new TextBlock
            {
                Background = txt.Background,
                FontSize = txt.FontSize,
                FontWeight = txt.FontWeight,
                Foreground = txt.Foreground,
                TextAlignment = TextAlignment.Center,
                 Text = content

            };

            border.Child = text;
            emai.Children.Add(border);

        }
        public void addfrom(string content)
        {
            Border border = new Border
            {
                BorderBrush = pbd.BorderBrush,
                BorderThickness = pbd.BorderThickness,
            };
            border.Style = pbd.Style;
            TextBlock text = new TextBlock
            {
                Background = txt.Background,
                FontSize = txt.FontSize,
                FontWeight = txt.FontWeight,
                Foreground = txt.Foreground,
                TextAlignment = TextAlignment.Center,
                Text = content
            };

            border.Child = text;
            from.Children.Add(border);

        }
        public void addto(string content)
        {
            Border border = new Border
            {
                BorderBrush = pbd.BorderBrush,
                BorderThickness = pbd.BorderThickness,
            };
            border.Style = pbd.Style;
            TextBlock text = new TextBlock
            {
                Background = txt.Background,
                FontSize = txt.FontSize,
                FontWeight = txt.FontWeight,
                Foreground = txt.Foreground,
                TextAlignment = TextAlignment.Center,
                Text = content
            };

            border.Child = text;
            dest.Children.Add(border);

        }
        public void addprice(string content)
        {
            Border border = new Border
            {
                BorderBrush = pbd.BorderBrush,
                BorderThickness = pbd.BorderThickness,
            };
            border.Style = pbd.Style;
            TextBlock text = new TextBlock
            {
                Background = txt.Background,
                FontSize = txt.FontSize,
                FontWeight = txt.FontWeight,
                Foreground = txt.Foreground,
                TextAlignment = TextAlignment.Center,
                Text = content
            };

            border.Child = text;
            paid.Children.Add(border);

        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window Win = new Window {
                AllowsTransparency = true,
                WindowStyle = WindowStyle.None,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                Height = 150,
                Width = 430,
                Background = new SolidColorBrush(Colors.Transparent),
                ShowInTaskbar= false,
            };
            Border border = new Border { 
                Background=new SolidColorBrush(Colors.White),
                CornerRadius= new CornerRadius(9),
                BorderBrush=new SolidColorBrush(Colors.Black),
                BorderThickness= new Thickness(2),
            };
            StackPanel stack = new StackPanel();
            Button button = new Button {
                Background=btn.Background,
                FontSize= btn.FontSize,FontWeight= btn.FontWeight,Foreground=btn.Foreground,
                HorizontalAlignment= HorizontalAlignment.Right,
                VerticalAlignment= VerticalAlignment.Bottom,
                Margin=new Thickness(0,60,10,0),
            };
            button.Style= btn.Style;
        
            button.Template=btn.Template;
            button.Click += Close;
         
            Button button1 = new Button
            {
                Background = btn.Background,
                FontSize = btn.FontSize,
                FontWeight = btn.FontWeight,
                Foreground = btn.Foreground,
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(10, -50, 0, 0),
            };
            button1.Click += no;
            TextBlock text = new TextBlock {
                FontSize = btn.FontSize,
                FontWeight = btn.FontWeight,
                Foreground = new SolidColorBrush(Colors.Black),
                Text="Do You Wish To Exit The Application?",
                HorizontalAlignment= HorizontalAlignment.Center,
                VerticalAlignment= VerticalAlignment.Center,
                Margin = new Thickness(0,0, 0,0),
            };
            button1.Style = btn2.Style;

            button1.Template = btn2.Template;
            ;
            stack.Children.Add(text);
            stack.Children.Add (button);
            stack.Children.Add(button1);
            border.Child = stack;
            Win.Content= border;
            if (Win.WindowState == WindowState.Maximized)
            {
                Win.Close();
            }
           Win.Show();
           
        }
        private void Close(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void no(object sender, RoutedEventArgs e)
        {
            Window window = Window.GetWindow(sender as Button);
            window.Close();
        }
        private void btnDashboard_Click(object sender, RoutedEventArgs e)

        {
            og.Opacity = 1;
            report1.Margin = new Thickness(0, 10, 0, 0);

            conn.Open();
            string queryString1 = "select count(*) from BUS_SCHEDULES";
            SqlCommand command1 = new SqlCommand(queryString1, conn);
            int count = (int)command1.ExecuteScalar();
            num.Text = string.Empty;
            num.Text = count.ToString();

            conn.Close();

            conn.Open();
            string queryString2 = "select count(*) from History";
            SqlCommand command2 = new SqlCommand(queryString2, conn);
            int count2 = (int)command2.ExecuteScalar();
            num2.Text = string.Empty;
            num2.Text = count2.ToString();

            conn.Close();



          
            hero.Children.Clear();
            parent.Children.Clear();
            conn.Open();
            SqlCommand command = new SqlCommand("select  From_T,To_T,Ticket_Id,Price from History", conn);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Border bd = new Border
                {
                    Background = BD.Background,
                    Height = BD.Height,
                    Width = BD.Width,
                    CornerRadius = BD.CornerRadius,
                    VerticalAlignment = BD.VerticalAlignment,
                    Margin = BD.Margin
                };
                StackPanel stack = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                };
                TextBlock name = new TextBlock
                {
                    Height = t1.Height,
                    Width = t1.Width,
                    Foreground = t1.Foreground,
                    FontWeight = t1.FontWeight,
                    VerticalAlignment = t1.VerticalAlignment,
                    Margin = t1.Margin,
                    FontSize = t1.FontSize,
                    Text = "Katlo Pole"

                };
                TextBlock from = new TextBlock
                {
                    Height = t2.Height,
                    Width = t2.Width,
                    Foreground = t2.Foreground,
                    FontWeight = t2.FontWeight,
                    VerticalAlignment = t2.VerticalAlignment,
                    Margin = t2.Margin,
                    FontSize = t1.FontSize,
                    Text = reader.GetString(0)

                };
                TextBlock to = new TextBlock
                {
                    Height = t3.Height,
                    Width = t3.Width,
                    Foreground = t3.Foreground,
                    FontWeight = t3.FontWeight,
                    VerticalAlignment = t3.VerticalAlignment,
                    Margin = t3.Margin,
                    FontSize = t3.FontSize,
                    Text = reader.GetString(1)
                };
                TextBlock qnt = new TextBlock
                {
                    Height = t4.Height,
                    Width = t4.Width,
                    Foreground = t4.Foreground,
                    FontWeight = t4.FontWeight,
                    VerticalAlignment = t4.VerticalAlignment,
                    Margin = t4.Margin,
                    FontSize = t4.FontSize,
                    Text = reader.GetString(2)
                };
                TextBlock price = new TextBlock
                {
                    Height = t5.Height,
                    Width = t5.Width,
                    Foreground = t5.Foreground,
                    FontWeight = t5.FontWeight,
                    VerticalAlignment = t5.VerticalAlignment,
                    Margin = t5.Margin,
                    FontSize = t5.FontSize,
                    Text = reader.GetString(3)
                };
                stack.Children.Add(name);
                stack.Children.Add(from);
                stack.Children.Add(to);
                stack.Children.Add(qnt);
                stack.Children.Add(price);
                bd.Child = stack;
                parent.Children.Add(bd);

            }
            conn.Close();

            hero.Children.Add(og);
        }
     

        private void btnSchedule_Click(object sender, RoutedEventArgs e)
        {
            change = 1;
           
            string xaml = @"
  
       <StackPanel Grid.Row=""2""  xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' >
                    <Border Background=""Transparent"" Width=""848"" Margin=""0,30,0,0"" CornerRadius=""12"" Height=""614"">
                        <StackPanel>
                             <TextBlock Foreground=""#FF301963"" Margin=""10,0,0,0"" Text=""Bus(es) On Schedule"" FontSize=""23"" FontWeight=""ExtraBold""/>
                            <Border CornerRadius=""9"" Background=""#FF2F153A"" Height=""511"" Width=""834"">
                                <StackPanel>
                                    <Border Background=""#FF3F445F"" Height=""34"" CornerRadius=""9"">
                                        <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Driver"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""120,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""From"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""85,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Destination"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""95,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Depature"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""75,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Arrive"" Height=""26""></TextBlock>
                                               <TextBlock Foreground=""White"" FontSize=""17"" Margin=""35,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Date"" Height=""26""></TextBlock>
                                        </StackPanel>
                                    </Border>
                                    <ScrollViewer  VerticalScrollBarVisibility=""Hidden"" Height=""468"" Margin=""0,0,0,0"">
                                      <StackPanel>
                                             <Border  Background=""#623ed0"" Height=""34"" VerticalAlignment=""Top"" CornerRadius=""9"" Margin=""0,10,0,0"">
                                            <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Katlo Pole"" Width=""150"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""15,3,0,0"" Width=""125"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Gaborone"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""8,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Width=""120"" Text=""Fancistown"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""65,3,0,0"" Width=""120"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""3 Ticket(s)"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""25,3,0,0"" Width=""80"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""P127.00"" Height=""26""/>
                                                 <TextBlock Foreground=""White"" FontSize=""17"" Margin=""5,3,0,0"" Width=""95"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""01/12/2002"" Height=""26""/>
                                                  <Button Background=""#FFE21F1F"" Margin=""-8,0,0,0"" >

                                                    <Button.Template>
                                                        <ControlTemplate TargetType=""Button"">
                                                            <Border Width=""29"" Height=""28"" CornerRadius=""0,0,9,0""
                                      Margin=""0,0,800,0""
                                         >

                                                                <Border.Background>
                                                                    <ImageBrush ImageSource=""me.png"" ></ImageBrush>
                                                                </Border.Background>


                                                            </Border>
                                                        </ControlTemplate>

                                                    </Button.Template>
                                                </Button >
                                            </StackPanel>
                                        </Border>


                                      </StackPanel>
                                    </ScrollViewer>
                                </StackPanel>
                            </Border>
                            <StackPanel Orientation=""Horizontal"">
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""10,10,650,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">
                                           
                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""CREATE NEW""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""-170,10,0,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">

                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""Refresh""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                            </StackPanel>
<StackPanel Margin=""0,0,0,0"" Opacity=""0"">
                                <Border Background=""#E5120B2F""  CornerRadius=""12"" Width=""318"" Height=""410"">
                                    <StackPanel>
                                        <Button 
                           
                        FontSize=""14""
                        Foreground=""red""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""                  
                        FontStretch=""ExtraExpanded""
                            Margin=""290,0,0,0""
                        Height=""30"" VerticalAlignment=""Top""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""20"" Height=""20""
                                    CornerRadius=""20""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""X""
                                        VerticalAlignment=""Top""
                                        HorizontalAlignment=""Center"" Margin=""0,1,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,-20,0,0"" FontWeight=""Bold"" HorizontalAlignment=""Center"" VerticalAlignment=""Top"" Text=""Create New Bus Schedulle""  Height=""26""/>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-125,0,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Depature From"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent""  FontWeight=""Bold"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-55,10,70,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Destination"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent""  FontWeight=""Bold"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,10,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Depature Time"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0""   FontWeight=""Bold"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-124,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Arrive Time"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-38,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0""   FontWeight=""Bold"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-107,10,20,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Date"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""129"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0""  FontWeight=""Bold"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Driver"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-39,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""129"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0""  FontWeight=""Bold"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-129,10,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Bus Id"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>

                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Price(BWP)"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-38,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <Button 
                           
                        FontSize=""17""
                        Foreground=""White""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""  
                        HorizontalAlignment=""Center""                     
                        FontStretch=""ExtraExpanded""
                            Margin=""0,20,0,0""
                        Height=""40"" Width=""132""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""130"" Height=""38""
                                    CornerRadius=""3""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""CREATE""
                                        VerticalAlignment=""Center""
                                        HorizontalAlignment=""Center"" Margin=""0,0,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                    </StackPanel>
                                </Border>
                            </StackPanel>
                        </StackPanel>
                    </Border>
                </StackPanel>
  
";
                StackPanel Template = (StackPanel)XamlReader.Parse(xaml);
                /*  StackPanel panel1= (StackPanel)Template.Children[0];*/
                Border bd1 = (Border)Template.Children[0];
                StackPanel panel2 = (StackPanel)bd1.Child;
                TextBlock text = (TextBlock)panel2.Children[0];
                Border bd2 = (Border)panel2.Children[1];
                StackPanel panel3 = (StackPanel)bd2.Child;
                ScrollViewer scroll = (ScrollViewer)panel3.Children[1];
                StackPanel panel30 = (StackPanel)scroll.Content;
                Border bd3 = (Border)panel30.Children[0];
                //get text block
                StackPanel panel4 = (StackPanel)bd3.Child;
                TextBlock driver = (TextBlock)panel4.Children[0];
                TextBlock from = (TextBlock)panel4.Children[1];
                TextBlock to = (TextBlock)panel4.Children[2];
                TextBlock via = (TextBlock)panel4.Children[3];
                TextBlock duration = (TextBlock)panel4.Children[4];
                TextBlock date = (TextBlock)panel4.Children[5];
                Button Menu = (Button)panel4.Children[6];
            Border newbd = new Border
            {
                Width = bd3.Width,
                Height = bd3.Height,
                Margin = new Thickness(0, 0, 0, 0),
                Background = bd3.Background,
                CornerRadius = bd3.CornerRadius,
                VerticalAlignment = VerticalAlignment.Top
            };
               
          

             
                panel30.Children.Remove(bd3);
            
         

            //get buttons
            StackPanel panel6 = (StackPanel)panel2.Children[2];
                Button createnew = (Button)panel6.Children[0];
                createnew.Click += Create;
                Button refresh = (Button)panel6.Children[1];
                //create schedule Form
                StackPanel panel7 = (StackPanel)panel2.Children[3];
                Border bd4 = (Border)panel7.Children[0];
                StackPanel panel8 = (StackPanel)bd4.Child;
                Button close = (Button)panel8.Children[0];
                close.Click += CloseCreate;
                hero.Children.Clear();
            conn.Open();
            SqlCommand command = new SqlCommand("select  DRIVER,BUS_FROM,BUS_TO,DEPATURE_TIME,ARRIVE_TIME,Bus_Date from BUS_SCHEDULES", conn);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Border new1 = new Border
                {
                    Width = bd3.Width,
                    Height = bd3.Height,
                    Margin = new Thickness(0,3, 0, 0),
                    Background = bd3.Background,
                    CornerRadius = bd3.CornerRadius,
                    VerticalAlignment = VerticalAlignment.Top
                };

                StackPanel panel5 = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                };
                TextBlock Driver = new TextBlock
                {
                    FontSize = driver.FontSize,
                    Width = driver.Width,
                    Height = driver.Height,
                    Foreground = driver.Foreground,
                    FontWeight = driver.FontWeight,
                    Margin = driver.Margin,
                    VerticalAlignment = driver.VerticalAlignment,
                    Text = reader.GetString(0).ToUpper(),
                };
                TextBlock From = new TextBlock
                {
                    FontSize = from.FontSize,
                    Width = from.Width,
                    Height = from.Height,
                    Foreground = from.Foreground,
                    FontWeight = from.FontWeight,
                    Margin = from.Margin,
                    VerticalAlignment = from.VerticalAlignment,
                       Text = reader.GetString(1).ToUpper()
                };
                TextBlock To = new TextBlock
                {
                    FontSize = to.FontSize,
                    Width = to.Width,
                    Height = to.Height,
                    Foreground = to.Foreground,
                    FontWeight = to.FontWeight,
                    Margin = to.Margin,
                    VerticalAlignment = to.VerticalAlignment,
                    Text = reader.GetString(2).ToUpper()
                };
                TextBlock dep = new TextBlock
                {
                    FontSize = via.FontSize,
                    Width = via.Width,
                    Height = via.Height,
                    Foreground = via.Foreground,
                    FontWeight = via.FontWeight,
                    Margin = via.Margin,
                    VerticalAlignment = via.VerticalAlignment,
                    Text = reader.GetString(3).ToUpper()
                };
                TextBlock arr = new TextBlock
                {
                    FontSize = via.FontSize,
                    Width = duration.Width,
                    Height = duration.Height,
                    Foreground = duration.Foreground,
                    FontWeight = duration.FontWeight,
                    Margin = duration.Margin,
                    VerticalAlignment = duration.VerticalAlignment,
                    Text = reader.GetString(4).ToUpper()
                };
                TextBlock Date = new TextBlock
                {
                    FontSize = date.FontSize,
                    Width = date.Width,
                    Height = date.Height,
                    Foreground = date.Foreground,
                    FontWeight = date.FontWeight,
                    Margin = date.Margin,
                    VerticalAlignment = date.VerticalAlignment,
                    Text = reader.GetString(5).ToUpper()
                };
                panel5.Children.Add(Driver);
                panel5.Children.Add(From); panel5.Children.Add(To);
                panel5.Children.Add(dep);panel5.Children.Add(arr);
                panel5.Children.Add(Date);

                Button Men = new Button
                {
                    Background = Menu.Background,
                    Margin = Menu.Margin,
                };
                Men.Template = Menu.Template;
                panel5.Children.Add(Men);
                new1.Child= panel5;
                panel30.Children.Add(new1);

            }

            conn.Close();
            hero.Children.Add(Template);
            
            
        }

        private void btnadd(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender as Button;
             StackPanel parent = (StackPanel)btn.Parent;
             Border bd1 = (Border)parent.Children[3];
             TextBox name = (TextBox)bd1.Child;
             Border bd2 = (Border)parent.Children[5];
             TextBox last = (TextBox)bd2.Child;
             Border bd3 = (Border)parent.Children[7];
             TextBox email = (TextBox)bd3.Child;
             Border bd4 = (Border)parent.Children[9];
             TextBox phone = (TextBox)bd4.Child;
             Border bd5 = (Border)parent.Children[11];
             TextBox gender = (TextBox)bd5.Child;
             Border bd6 = (Border)parent.Children[13];
             TextBox status = (TextBox)bd6.Child;

             if (name.Text == string.Empty && last.Text == string.Empty && email.Text == string.Empty && phone.Text == string.Empty && status.Text == string.Empty)
             {
                 MessageBox.Show("PLEASE EDIT THE SCHEDULE FORM");
             }
             else
             {
                 conn.Open();
                 SqlCommand comm = conn.CreateCommand();

                 comm.CommandText = "insert into Employees values('" + name.Text.ToLower() + "','" + last.Text.ToLower() + "','" + email.Text.ToLower() + "','" + phone.Text.ToLower() + "','" + status.Text.ToLower() + "','" + gender.Text.ToLower() + "')";
                 comm.ExecuteNonQuery();
                 conn.Close();
                name.Text = string.Empty;
                last.Text = string.Empty;  email.Text = string.Empty;  phone.Text = string.Empty; status.Text = string.Empty;
             }
        }
        public void refresher()
        {

            string xaml = @"
  
       <StackPanel Grid.Row=""2""  xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' >
                    <Border Background=""Transparent"" Width=""848"" Margin=""0,30,0,0"" CornerRadius=""12"" Height=""614"">
                        <StackPanel>
                             <TextBlock Foreground=""#FF301963"" Margin=""10,0,0,0"" Text=""Bus(es) On Schedule"" FontSize=""23"" FontWeight=""ExtraBold""/>
                            <Border CornerRadius=""9"" Background=""#FF2F153A"" Height=""511"" Width=""834"">
                                <StackPanel>
                                    <Border Background=""#FF3F445F"" Height=""34"" CornerRadius=""9"">
                                        <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Driver"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""120,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""From"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""85,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Destination"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""95,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Depature"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""75,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Arrive"" Height=""26""></TextBlock>
                                               <TextBlock Foreground=""White"" FontSize=""17"" Margin=""35,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Date"" Height=""26""></TextBlock>
                                        </StackPanel>
                                    </Border>
                                    <ScrollViewer  VerticalScrollBarVisibility=""Hidden"" Height=""468"" Margin=""0,0,0,0"">
                                      <StackPanel>
                                             <Border  Background=""#623ed0"" Height=""34"" VerticalAlignment=""Top"" CornerRadius=""9"" Margin=""0,10,0,0"">
                                            <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Katlo Pole"" Width=""150"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""15,3,0,0"" Width=""125"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Gaborone"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""8,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Width=""120"" Text=""Fancistown"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""65,3,0,0"" Width=""120"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""3 Ticket(s)"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""25,3,0,0"" Width=""80"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""P127.00"" Height=""26""/>
                                                 <TextBlock Foreground=""White"" FontSize=""17"" Margin=""5,3,0,0"" Width=""95"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""01/12/2002"" Height=""26""/>
                                                  <Button Background=""#FFE21F1F"" Margin=""-8,0,0,0"" >

                                                    <Button.Template>
                                                        <ControlTemplate TargetType=""Button"">
                                                            <Border Width=""29"" Height=""28"" CornerRadius=""0,0,9,0""
                                      Margin=""0,0,800,0""
                                         >

                                                                <Border.Background>
                                                                    <ImageBrush ImageSource=""me.png"" ></ImageBrush>
                                                                </Border.Background>


                                                            </Border>
                                                        </ControlTemplate>

                                                    </Button.Template>
                                                </Button >
                                            </StackPanel>
                                        </Border>


                                      </StackPanel>
                                    </ScrollViewer>
                                </StackPanel>
                            </Border>
                            <StackPanel Orientation=""Horizontal"">
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""10,10,650,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">
                                           
                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""CREATE NEW""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""-170,10,0,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">

                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""Refresh""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                            </StackPanel>
<StackPanel Margin=""0,0,0,0"" Opacity=""0"">
                                <Border Background=""#E5120B2F""  CornerRadius=""12"" Width=""318"" Height=""410"">
                                    <StackPanel>
                                        <Button 
                           
                        FontSize=""14""
                        Foreground=""red""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""                  
                        FontStretch=""ExtraExpanded""
                            Margin=""290,0,0,0""
                        Height=""30"" VerticalAlignment=""Top""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""20"" Height=""20""
                                    CornerRadius=""20""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""X""
                                        VerticalAlignment=""Top""
                                        HorizontalAlignment=""Center"" Margin=""0,1,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,-20,0,0"" FontWeight=""Bold"" HorizontalAlignment=""Center"" VerticalAlignment=""Top"" Text=""Create New Bus Schedulle""  Height=""26""/>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-125,0,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Depature From"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent""  FontWeight=""Bold"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-55,10,70,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Destination"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent""  FontWeight=""Bold"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,10,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Depature Time"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0""   FontWeight=""Bold"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-124,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Arrive Time"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-38,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0""   FontWeight=""Bold"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-107,10,20,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Date"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""129"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0""  FontWeight=""Bold"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Driver"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-39,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""129"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0""  FontWeight=""Bold"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-129,10,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Bus Id"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>

                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Price(BWP)"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-38,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <Button 
                           
                        FontSize=""17""
                        Foreground=""White""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""  
                        HorizontalAlignment=""Center""                     
                        FontStretch=""ExtraExpanded""
                            Margin=""0,20,0,0""
                        Height=""40"" Width=""132""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""130"" Height=""38""
                                    CornerRadius=""3""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""CREATE""
                                        VerticalAlignment=""Center""
                                        HorizontalAlignment=""Center"" Margin=""0,0,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                    </StackPanel>
                                </Border>
                            </StackPanel>
                        </StackPanel>
                    </Border>
                </StackPanel>
  
";
            StackPanel Template = (StackPanel)XamlReader.Parse(xaml);
            /*  StackPanel panel1= (StackPanel)Template.Children[0];*/
            Border bd1 = (Border)Template.Children[0];
            StackPanel panel2 = (StackPanel)bd1.Child;
            TextBlock text = (TextBlock)panel2.Children[0];
            Border bd2 = (Border)panel2.Children[1];
            StackPanel panel3 = (StackPanel)bd2.Child;
            ScrollViewer scroll = (ScrollViewer)panel3.Children[1];
            StackPanel panel30 = (StackPanel)scroll.Content;
            Border bd3 = (Border)panel30.Children[0];
            //get text block
            StackPanel panel4 = (StackPanel)bd3.Child;
            TextBlock driver = (TextBlock)panel4.Children[0];
            TextBlock from = (TextBlock)panel4.Children[1];
            TextBlock to = (TextBlock)panel4.Children[2];
            TextBlock via = (TextBlock)panel4.Children[3];
            TextBlock duration = (TextBlock)panel4.Children[4];
            TextBlock date = (TextBlock)panel4.Children[5];
            Button Menu = (Button)panel4.Children[6];
            Border newbd = new Border
            {
                Width = bd3.Width,
                Height = bd3.Height,
                Margin = new Thickness(0, 0, 0, 0),
                Background = bd3.Background,
                CornerRadius = bd3.CornerRadius,
                VerticalAlignment = VerticalAlignment.Top
            };




            panel30.Children.Remove(bd3);



            //get buttons
            StackPanel panel6 = (StackPanel)panel2.Children[2];
            Button createnew = (Button)panel6.Children[0];
            createnew.Click += Create;
            Button refresh = (Button)panel6.Children[1];
            //create schedule Form
            StackPanel panel7 = (StackPanel)panel2.Children[3];
            Border bd4 = (Border)panel7.Children[0];
            StackPanel panel8 = (StackPanel)bd4.Child;
            Button close = (Button)panel8.Children[0];
            close.Click += CloseCreate;
            hero.Children.Clear();
            conn.Open();
            SqlCommand command = new SqlCommand("select  DRIVER,BUS_FROM,BUS_TO,DEPATURE_TIME,ARRIVE_TIME,Bus_Date from BUS_SCHEDULES", conn);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Border new1 = new Border
                {
                    Width = bd3.Width,
                    Height = bd3.Height,
                    Margin = new Thickness(0, 3, 0, 0),
                    Background = bd3.Background,
                    CornerRadius = bd3.CornerRadius,
                    VerticalAlignment = VerticalAlignment.Top
                };

                StackPanel panel5 = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                };
                TextBlock Driver = new TextBlock
                {
                    FontSize = driver.FontSize,
                    Width = driver.Width,
                    Height = driver.Height,
                    Foreground = driver.Foreground,
                    FontWeight = driver.FontWeight,
                    Margin = driver.Margin,
                    VerticalAlignment = driver.VerticalAlignment,
                    Text = reader.GetString(0).ToUpper(),
                };
                TextBlock From = new TextBlock
                {
                    FontSize = from.FontSize,
                    Width = from.Width,
                    Height = from.Height,
                    Foreground = from.Foreground,
                    FontWeight = from.FontWeight,
                    Margin = from.Margin,
                    VerticalAlignment = from.VerticalAlignment,
                    Text = reader.GetString(1).ToUpper()
                };
                TextBlock To = new TextBlock
                {
                    FontSize = to.FontSize,
                    Width = to.Width,
                    Height = to.Height,
                    Foreground = to.Foreground,
                    FontWeight = to.FontWeight,
                    Margin = to.Margin,
                    VerticalAlignment = to.VerticalAlignment,
                    Text = reader.GetString(2).ToUpper()
                };
                TextBlock dep = new TextBlock
                {
                    FontSize = via.FontSize,
                    Width = via.Width,
                    Height = via.Height,
                    Foreground = via.Foreground,
                    FontWeight = via.FontWeight,
                    Margin = via.Margin,
                    VerticalAlignment = via.VerticalAlignment,
                    Text = reader.GetString(3).ToUpper()
                };
                TextBlock arr = new TextBlock
                {
                    FontSize = via.FontSize,
                    Width = duration.Width,
                    Height = duration.Height,
                    Foreground = duration.Foreground,
                    FontWeight = duration.FontWeight,
                    Margin = duration.Margin,
                    VerticalAlignment = duration.VerticalAlignment,
                    Text = reader.GetString(4).ToUpper()
                };
                TextBlock Date = new TextBlock
                {
                    FontSize = date.FontSize,
                    Width = date.Width,
                    Height = date.Height,
                    Foreground = date.Foreground,
                    FontWeight = date.FontWeight,
                    Margin = date.Margin,
                    VerticalAlignment = date.VerticalAlignment,
                    Text = reader.GetString(5).ToUpper()
                };
                panel5.Children.Add(Driver);
                panel5.Children.Add(From); panel5.Children.Add(To);
                panel5.Children.Add(dep); panel5.Children.Add(arr);
                panel5.Children.Add(Date);

                Button Men = new Button
                {
                    Background = Menu.Background,
                    Margin = Menu.Margin,
                };
                Men.Template = Menu.Template;
                panel5.Children.Add(Men);
                new1.Child = panel5;
                panel30.Children.Add(new1);

            }

            conn.Close();
            hero.Children.Add(Template);
        }
        private void Create(object sender, RoutedEventArgs e)
        {

            string xaml = @"
  
       <StackPanel Grid.Row=""2""  xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' >
                    <Border Background=""Transparent"" Width=""848"" Margin=""0,30,0,0"" CornerRadius=""12"" Height=""614"">
                        <StackPanel>
                             <TextBlock Foreground=""#FF301963"" Margin=""10,0,0,0"" Text=""Bus(es) On Schedule"" FontSize=""23"" FontWeight=""ExtraBold""/>
                            <Border CornerRadius=""9"" Background=""#FF2F153A"" Height=""511"" Width=""834"">
                                <StackPanel>
                                    <Border Background=""#FF3F445F"" Height=""34"" CornerRadius=""9"">
                                        <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Driver"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""120,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""From"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""85,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Destination"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""95,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Depature"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""75,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Arrive"" Height=""26""></TextBlock>
                                               <TextBlock Foreground=""White"" FontSize=""17"" Margin=""35,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Date"" Height=""26""></TextBlock>
                                        </StackPanel>
                                    </Border>
                                    <ScrollViewer  VerticalScrollBarVisibility=""Hidden"" Height=""468"" Margin=""0,0,0,0"">
                                      <StackPanel>
                                             <Border  Background=""#623ed0"" Height=""34"" VerticalAlignment=""Top"" CornerRadius=""9"" Margin=""0,10,0,0"">
                                            <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Katlo Pole"" Width=""150"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""15,3,0,0"" Width=""125"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Gaborone"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""8,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Width=""120"" Text=""Fancistown"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""65,3,0,0"" Width=""120"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""3 Ticket(s)"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""25,3,0,0"" Width=""80"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""P127.00"" Height=""26""/>
                                                 <TextBlock Foreground=""White"" FontSize=""17"" Margin=""5,3,0,0"" Width=""95"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""01/12/2002"" Height=""26""/>
                                                  <Button Background=""#FFE21F1F"" Margin=""-8,0,0,0"" >

                                                    <Button.Template>
                                                        <ControlTemplate TargetType=""Button"">
                                                            <Border Width=""29"" Height=""28"" CornerRadius=""0,0,9,0""
                                      Margin=""0,0,800,0""
                                         >

                                                                <Border.Background>
                                                                    <ImageBrush ImageSource=""me.png"" ></ImageBrush>
                                                                </Border.Background>


                                                            </Border>
                                                        </ControlTemplate>

                                                    </Button.Template>
                                                </Button >
                                            </StackPanel>
                                        </Border>


                                      </StackPanel>
                                    </ScrollViewer>
                                </StackPanel>
                            </Border>
                            <StackPanel Orientation=""Horizontal"">
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""10,10,650,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">
                                           
                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""CREATE NEW""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""-170,10,0,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">

                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""Refresh""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                            </StackPanel>
<StackPanel Margin=""0,0,0,0"" Opacity=""0"">
                                <Border Background=""#E5120B2F""  CornerRadius=""12"" Width=""318"" Height=""470"">
                                    <StackPanel>
                                        <Button 
                           
                        FontSize=""14""
                        Foreground=""red""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""                  
                        FontStretch=""ExtraExpanded""
                            Margin=""290,0,0,0""
                        Height=""30"" VerticalAlignment=""Top""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""20"" Height=""20""
                                    CornerRadius=""20""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""X""
                                        VerticalAlignment=""Top""
                                        HorizontalAlignment=""Center"" Margin=""0,1,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,-20,0,0"" FontWeight=""Bold"" HorizontalAlignment=""Center"" VerticalAlignment=""Top"" Text=""Create New Bus Schedulle""  Height=""26""/>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-125,0,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Depature From"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent""  FontWeight=""Bold"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-55,10,70,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Destination"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent""  FontWeight=""Bold"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,10,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top""  Text=""Arrive Time"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0""   FontWeight=""Bold"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-124,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top""  Text=""Depature Time""  Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-38,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0""   FontWeight=""Bold"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-107,10,20,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Date"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""129"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0""  FontWeight=""Bold"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Driver"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-39,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""129"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0""  FontWeight=""Bold"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-129,10,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Bus Id"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>

                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Price(BWP)"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-38,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <Button 
                           
                        FontSize=""17""
                        Foreground=""White""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""  
                        HorizontalAlignment=""Center""                     
                        FontStretch=""ExtraExpanded""
                            Margin=""0,20,0,0""
                        Height=""40"" Width=""132""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""130"" Height=""38""
                                    CornerRadius=""3""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""CREATE""
                                        VerticalAlignment=""Center""
                                        HorizontalAlignment=""Center"" Margin=""0,0,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                    </StackPanel>
                                </Border>
                            </StackPanel>
                        </StackPanel>
                    </Border>
                </StackPanel>
  
";
            StackPanel Template = (StackPanel)XamlReader.Parse(xaml);
            /*  StackPanel panel1= (StackPanel)Template.Children[0];*/
            Border bd1 = (Border)Template.Children[0];
            StackPanel panel2 = (StackPanel)bd1.Child;
            TextBlock text = (TextBlock)panel2.Children[0];
            Border bd2 = (Border)panel2.Children[1];
            StackPanel panel3 = (StackPanel)bd2.Child;
            ScrollViewer scroll = (ScrollViewer)panel3.Children[1];
            StackPanel panel30 = (StackPanel)scroll.Content;
            Border bd3 = (Border)panel30.Children[0];
            //get text block
            StackPanel panel4 = (StackPanel)bd3.Child;
            TextBlock driver = (TextBlock)panel4.Children[0];
            TextBlock from = (TextBlock)panel4.Children[1];
            TextBlock to = (TextBlock)panel4.Children[2];
            TextBlock via = (TextBlock)panel4.Children[3];
            TextBlock duration = (TextBlock)panel4.Children[4];
            TextBlock date = (TextBlock)panel4.Children[5];
            Button Menu = (Button)panel4.Children[6];
            Border newbd = new Border
            {
                Width = bd3.Width,
                Height = bd3.Height,
                Margin = new Thickness(0, 0, 0, 0),
                Background = bd3.Background,
                CornerRadius = bd3.CornerRadius,
                VerticalAlignment = VerticalAlignment.Top
            };




            panel30.Children.Remove(bd3);



            //get buttons
            StackPanel panel6 = (StackPanel)panel2.Children[2];
            Button createnew = (Button)panel6.Children[0];
            createnew.Click += Create;
            Button refresh = (Button)panel6.Children[1];
            //create schedule Form
            StackPanel panel7 = (StackPanel)panel2.Children[3];
            Border bd4 = (Border)panel7.Children[0];
            StackPanel panel8 = (StackPanel)bd4.Child;
            Button close = (Button)panel8.Children[0];
            Button btncreate = (Button)panel8.Children[18];
            btncreate.Click += btnCreate;
            close.Click += CloseCreate;
            panel7.Opacity = 1;
            panel7.Margin = new Thickness(0, -500, 0, 0);
            hero.Children.Clear();
            conn.Open();
            SqlCommand command = new SqlCommand("select  DRIVER,BUS_FROM,BUS_TO,DEPATURE_TIME,ARRIVE_TIME,Bus_Date from BUS_SCHEDULES", conn);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Border new1 = new Border
                {
                    Width = bd3.Width,
                    Height = bd3.Height,
                    Margin = new Thickness(0, 3, 0, 0),
                    Background = bd3.Background,
                    CornerRadius = bd3.CornerRadius,
                    VerticalAlignment = VerticalAlignment.Top
                };

                StackPanel panel5 = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                };
                TextBlock Driver = new TextBlock
                {
                    FontSize = driver.FontSize,
                    Width = driver.Width,
                    Height = driver.Height,
                    Foreground = driver.Foreground,
                    FontWeight = driver.FontWeight,
                    Margin = driver.Margin,
                    VerticalAlignment = driver.VerticalAlignment,
                    Text = reader.GetString(0).ToUpper(),
                };
                TextBlock From = new TextBlock
                {
                    FontSize = from.FontSize,
                    Width = from.Width,
                    Height = from.Height,
                    Foreground = from.Foreground,
                    FontWeight = from.FontWeight,
                    Margin = from.Margin,
                    VerticalAlignment = from.VerticalAlignment,
                    Text = reader.GetString(1).ToUpper()
                };
                TextBlock To = new TextBlock
                {
                    FontSize = to.FontSize,
                    Width = to.Width,
                    Height = to.Height,
                    Foreground = to.Foreground,
                    FontWeight = to.FontWeight,
                    Margin = to.Margin,
                    VerticalAlignment = to.VerticalAlignment,
                    Text = reader.GetString(2).ToUpper()
                };
                TextBlock dep = new TextBlock
                {
                    FontSize = via.FontSize,
                    Width = via.Width,
                    Height = via.Height,
                    Foreground = via.Foreground,
                    FontWeight = via.FontWeight,
                    Margin = via.Margin,
                    VerticalAlignment = via.VerticalAlignment,
                    Text = reader.GetString(3).ToUpper()
                };
                TextBlock arr = new TextBlock
                {
                    FontSize = via.FontSize,
                    Width = duration.Width,
                    Height = duration.Height,
                    Foreground = duration.Foreground,
                    FontWeight = duration.FontWeight,
                    Margin = duration.Margin,
                    VerticalAlignment = duration.VerticalAlignment,
                    Text = reader.GetString(4).ToUpper()
                };
                TextBlock Date = new TextBlock
                {
                    FontSize = date.FontSize,
                    Width = date.Width,
                    Height = date.Height,
                    Foreground = date.Foreground,
                    FontWeight = date.FontWeight,
                    Margin = date.Margin,
                    VerticalAlignment = date.VerticalAlignment,
                    Text = reader.GetString(5).ToUpper()
                };
                panel5.Children.Add(Driver);
                panel5.Children.Add(From); panel5.Children.Add(To);
                panel5.Children.Add(dep); panel5.Children.Add(arr);
                panel5.Children.Add(Date);

                Button Men = new Button
                {
                    Background = Menu.Background,
                    Margin = Menu.Margin,
                };
                Men.Template = Menu.Template;
                panel5.Children.Add(Men);
                new1.Child = panel5;
                panel30.Children.Add(new1);

            }

            conn.Close();
            hero.Children.Add(Template);
        }
        private void addnew(object sender, RoutedEventArgs e)
        {

            string xaml = @"
  
       <StackPanel Grid.Row=""2""  xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' >
                    <Border Background=""Transparent"" Width=""848"" Margin=""0,30,0,0"" CornerRadius=""12"" Height=""614"">
                        <StackPanel>
                             <TextBlock Foreground=""#FF301963"" Margin=""10,0,0,0"" Text=""Employees Details"" FontSize=""23"" FontWeight=""ExtraBold""/>
                            <Border CornerRadius=""9"" Background=""#FF2F153A"" Height=""511"" Width=""834"">
                                <StackPanel>
                                    <Border Background=""#FF3F445F"" Height=""34"" CornerRadius=""9"">
                                        <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Firstname"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""40,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Lastname"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""45,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Email"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""156,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Phone"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""95,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Status"" Height=""26""></TextBlock>
                                             
                                        </StackPanel>
                                    </Border>
                                    <ScrollViewer  VerticalScrollBarVisibility=""Hidden"" Height=""468"" Margin=""0,0,0,0"">
                                      <StackPanel>
                                             <Border  Background=""#623ed0"" Height=""34"" VerticalAlignment=""Top"" CornerRadius=""9"" Margin=""0,10,0,0"">
                                            <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Katlo Pole"" Width=""105"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""15,3,0,0"" Width=""110"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Gaborone"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""8,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Width=""200"" Text=""Fancistown"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,3,0,0"" Width=""120"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""3 Ticket(s)"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""25,3,0,0"" Width=""100"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""P127.00"" Height=""26""/>
                                                 <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,3,0,0"" Width=""15"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""01/12/2002"" Height=""26""/>
                                                  <Button Background=""#FFE21F1F"" Margin=""115,0,0,0"" >

                                                    <Button.Template>
                                                        <ControlTemplate TargetType=""Button"">
                                                            <Border Width=""29"" Height=""28"" CornerRadius=""0,0,9,0""
                                      Margin=""0,0,800,0""
                                         >

                                                                <Border.Background>
                                                                    <ImageBrush ImageSource=""me.png"" ></ImageBrush>
                                                                </Border.Background>


                                                            </Border>
                                                        </ControlTemplate>

                                                    </Button.Template>
                                                </Button >
                                            </StackPanel>
                                        </Border>


                                      </StackPanel>
                                    </ScrollViewer>
                                </StackPanel>
                            </Border>
                            <StackPanel Orientation=""Horizontal"">
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""10,10,650,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">
                                           
                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""CREATE NEW""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""-170,10,0,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">

                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""Refresh""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                            </StackPanel>
<StackPanel Margin=""0,0,0,0"" Opacity=""0"">
                                <Border Background=""#E5120B2F""  CornerRadius=""12"" Width=""318"" Height=""470"">
                                    <StackPanel>
                                        <Button 
                           
                        FontSize=""14""
                        Foreground=""red""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""                  
                        FontStretch=""ExtraExpanded""
                            Margin=""290,0,0,0""
                        Height=""30"" VerticalAlignment=""Top""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""20"" Height=""20""
                                    CornerRadius=""20""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""X""
                                        VerticalAlignment=""Top""
                                        HorizontalAlignment=""Center"" Margin=""0,1,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                       <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,-20,0,0"" FontWeight=""Bold"" HorizontalAlignment=""Center"" VerticalAlignment=""Top"" Text=""Add New Employee""  Height=""26""/>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-125,0,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""First Name(s)"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-55,10,70,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Surname"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-124,0,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Email Address"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                       
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,10,220,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Route"" Width=""50"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-129,10,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Gender"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>

                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Phone"" Width=""150"" Height=""26""/>
                                        
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-38,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <Button 
                           
                        FontSize=""17""
                        Foreground=""White""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""  
                        HorizontalAlignment=""Center""                     
                        FontStretch=""ExtraExpanded""
                            Margin=""0,20,0,0""
                        Height=""40"" Width=""132""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""130"" Height=""38""
                                    CornerRadius=""3""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""ADD""
                                        VerticalAlignment=""Center""
                                        HorizontalAlignment=""Center"" Margin=""0,0,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                    </StackPanel>
                                </Border>
                            </StackPanel>
                        </StackPanel>
                    </Border>
                </StackPanel>
  
";
            StackPanel Template = (StackPanel)XamlReader.Parse(xaml);




            /*  StackPanel panel1= (StackPanel)Template.Children[0];*/
            Border bd1 = (Border)Template.Children[0];
            StackPanel panel2 = (StackPanel)bd1.Child;
            TextBlock text = (TextBlock)panel2.Children[0];
            Border bd2 = (Border)panel2.Children[1];
            StackPanel panel3 = (StackPanel)bd2.Child;
            ScrollViewer scroll = (ScrollViewer)panel3.Children[1];
            StackPanel panel30 = (StackPanel)scroll.Content;
            Border bd3 = (Border)panel30.Children[0];
            //get text block
            StackPanel panel4 = (StackPanel)bd3.Child;
            TextBlock driver = (TextBlock)panel4.Children[0];
            TextBlock from = (TextBlock)panel4.Children[1];
            TextBlock to = (TextBlock)panel4.Children[2];
            TextBlock via = (TextBlock)panel4.Children[3];
            TextBlock duration = (TextBlock)panel4.Children[4];
            TextBlock date = (TextBlock)panel4.Children[5];
            Button Menu = (Button)panel4.Children[6];
            Border newbd = new Border
            {
                Width = bd3.Width,
                Height = bd3.Height,
                Margin = new Thickness(0, 0, 0, 0),
                Background = bd3.Background,
                CornerRadius = bd3.CornerRadius,
                VerticalAlignment = VerticalAlignment.Top
            };




            panel30.Children.Remove(bd3);



            //get buttons
            StackPanel panel6 = (StackPanel)panel2.Children[2];
            Button createnew = (Button)panel6.Children[0];
            createnew.Click += addnew;
            Button refresh = (Button)panel6.Children[1];
            //create schedule Form
            StackPanel panel7 = (StackPanel)panel2.Children[3];
            Border bd4 = (Border)panel7.Children[0];
            StackPanel panel8 = (StackPanel)bd4.Child;
            Button close = (Button)panel8.Children[0];
            Button btncreate = (Button)panel8.Children[14];
            btncreate.Click += btnadd;
            close.Click += Reports_Click;
            hero.Children.Clear();
            conn.Open();
            SqlCommand command = new SqlCommand("select  FirstName,LastName,Email,Phone,Status from Employees", conn);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Border new1 = new Border
                {
                    Width = bd3.Width,
                    Height = bd3.Height,
                    Margin = new Thickness(0, 3, 0, 0),
                    Background = bd3.Background,
                    CornerRadius = bd3.CornerRadius,
                    VerticalAlignment = VerticalAlignment.Top
                };

                StackPanel panel5 = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                };
                TextBlock Driver = new TextBlock
                {
                    FontSize = driver.FontSize,
                    Width = driver.Width,
                    Height = driver.Height,
                    Foreground = driver.Foreground,
                    FontWeight = driver.FontWeight,
                    Margin = driver.Margin,
                    VerticalAlignment = driver.VerticalAlignment,
                    Text = reader.GetString(0).ToUpper(),
                };
                TextBlock From = new TextBlock
                {
                    FontSize = from.FontSize,
                    Width = from.Width,
                    Height = from.Height,
                    Foreground = from.Foreground,
                    FontWeight = from.FontWeight,
                    Margin = from.Margin,
                    VerticalAlignment = from.VerticalAlignment,
                    Text = reader.GetString(1).ToUpper()
                };
                TextBlock To = new TextBlock
                {
                    FontSize = to.FontSize,
                    Width = to.Width,
                    Height = to.Height,
                    Foreground = to.Foreground,
                    FontWeight = to.FontWeight,
                    Margin = to.Margin,
                    VerticalAlignment = to.VerticalAlignment,
                    Text = reader.GetString(2).ToUpper()
                };
                TextBlock dep = new TextBlock
                {
                    FontSize = via.FontSize,
                    Width = via.Width,
                    Height = via.Height,
                    Foreground = via.Foreground,
                    FontWeight = via.FontWeight,
                    Margin = via.Margin,
                    VerticalAlignment = via.VerticalAlignment,
                    Text = reader.GetString(4).ToUpper()
                };
                TextBlock arr = new TextBlock
                {
                    FontSize = via.FontSize,
                    Width = duration.Width,
                    Height = duration.Height,
                    Foreground = duration.Foreground,
                    FontWeight = duration.FontWeight,
                    Margin = duration.Margin,
                    VerticalAlignment = duration.VerticalAlignment,
                    Text = "On Schedule"
                };
                /*   TextBlock Date = new TextBlock
                   {
                       FontSize = date.FontSize,
                       Width = date.Width,
                       Height = date.Height,
                       Foreground = date.Foreground,
                       FontWeight = date.FontWeight,
                       Margin = date.Margin,
                       VerticalAlignment = date.VerticalAlignment,
                       Text = reader.GetString(4).ToUpper()
                   };*/
                panel5.Children.Add(Driver);
                panel5.Children.Add(From); panel5.Children.Add(To);
                panel5.Children.Add(dep); panel5.Children.Add(arr);
                /*    panel5.Children.Add(Date);*/

                Button Men = new Button
                {
                    Background = Menu.Background,
                    Margin = Menu.Margin,
                };
                Men.Template = Menu.Template;
                panel5.Children.Add(Men);
                new1.Child = panel5;
                panel7.Margin = new Thickness(0, -500, 0, 0);
                panel7.Opacity = 1;
                panel30.Children.Add(new1);

            }

            conn.Close();
            hero.Children.Add(Template);
        }
        private void btnCreate(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            StackPanel parent = (StackPanel)btn.Parent;
            Border bd1= (Border)parent.Children[3];
            TextBox from = (TextBox)bd1.Child;
            Border bd2 = (Border)parent.Children[5];
            TextBox to = (TextBox)bd2.Child;
            Border bd3 = (Border)parent.Children[7];
            TextBox dep = (TextBox)bd3.Child;
            Border bd4 = (Border)parent.Children[9];
            TextBox arr = (TextBox)bd4.Child;
            Border bd5 = (Border)parent.Children[11];
            TextBox date = (TextBox)bd5.Child;
            Border bd6 = (Border)parent.Children[13];
            TextBox driver = (TextBox)bd6.Child;
            Border bd7 = (Border)parent.Children[15];
            TextBox id = (TextBox)bd7.Child;
            Border bd8 = (Border)parent.Children[17];
            TextBox price = (TextBox)bd8.Child;
            if (from.Text == string.Empty && to.Text == string.Empty && dep.Text == string.Empty && arr.Text == string.Empty && date.Text == string.Empty && driver.Text == string.Empty && id.Text == string.Empty && price.Text == string.Empty)
            {
                MessageBox.Show("PLEASE EDIT THE SCHEDULE FORM");
            }
            else
            {
                conn.Open();
                SqlCommand comm = conn.CreateCommand();

                comm.CommandText = "insert into BUS_SCHEDULES values(NEWID(),'" + id.Text.ToLower() + "','" + driver.Text.ToLower() + "','" + from.Text.ToLower() + "','" + to.Text.ToLower() + "','" + dep.Text.ToLower() + "','" + arr.Text.ToLower() + "','" + date.Text.ToLower() + "','" + price.Text.ToLower() + "')";
                comm.ExecuteNonQuery();
                conn.Close();
            }
          
        }
        private void CloseCreate(object sender, RoutedEventArgs e)
        {
            string xaml = @"
  
       <StackPanel Grid.Row=""2""  xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' >
                    <Border Background=""Transparent"" Width=""848"" Margin=""0,30,0,0"" CornerRadius=""12"" Height=""614"">
                        <StackPanel>
                             <TextBlock Foreground=""#FF301963"" Margin=""10,0,0,0"" Text=""Bus(es) On Schedule"" FontSize=""23"" FontWeight=""ExtraBold""/>
                            <Border CornerRadius=""9"" Background=""#FF2F153A"" Height=""511"" Width=""834"">
                                <StackPanel>
                                    <Border Background=""#FF3F445F"" Height=""34"" CornerRadius=""9"">
                                        <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Firstname"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""120,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Lastname"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""85,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""EMail"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""95,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Phone"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""75,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Arrive"" Height=""26""></TextBlock>
                                               <TextBlock Foreground=""White"" FontSize=""17"" Margin=""35,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Status"" Height=""26""></TextBlock>
                                        </StackPanel>
                                    </Border>
                                    <ScrollViewer  VerticalScrollBarVisibility=""Hidden"" Height=""468"" Margin=""0,0,0,0"">
                                      <StackPanel>
                                             <Border  Background=""#623ed0"" Height=""34"" VerticalAlignment=""Top"" CornerRadius=""9"" Margin=""0,10,0,0"">
                                            <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Katlo Pole"" Width=""150"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""15,3,0,0"" Width=""125"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Gaborone"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""8,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Width=""120"" Text=""Fancistown"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""65,3,0,0"" Width=""120"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""3 Ticket(s)"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""25,3,0,0"" Width=""80"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""P127.00"" Height=""26""/>
                                                 <TextBlock Foreground=""White"" FontSize=""17"" Margin=""5,3,0,0"" Width=""12"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""01/12/200"" Height=""26""/>
                                                    <TextBlock Foreground=""White"" FontSize=""17"" Margin=""5,3,0,0"" Width=""95"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""01/12/2002"" Height=""26""/>
                                                  <Button Background=""#FFE21F1F"" Margin=""-8,0,0,0"" >

                                                    <Button.Template>
                                                        <ControlTemplate TargetType=""Button"">
                                                            <Border Width=""29"" Height=""28"" CornerRadius=""0,0,9,0""
                                      Margin=""0,0,800,0""
                                         >

                                                                <Border.Background>
                                                                    <ImageBrush ImageSource=""me.png"" ></ImageBrush>
                                                                </Border.Background>


                                                            </Border>
                                                        </ControlTemplate>

                                                    </Button.Template>
                                                </Button >
                                            </StackPanel>
                                        </Border>


                                      </StackPanel>
                                    </ScrollViewer>
                                </StackPanel>
                            </Border>
                            <StackPanel Orientation=""Horizontal"">
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""10,10,650,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">
                                           
                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""CREATE NEW""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""-170,10,0,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">

                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""Refresh""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                            </StackPanel>
<StackPanel Margin=""0,0,0,0"" Opacity=""0"">
                                <Border Background=""#E5120B2F""  CornerRadius=""12"" Width=""318"" Height=""410"">
                                    <StackPanel>
                                        <Button 
                           
                        FontSize=""14""
                        Foreground=""red""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""                  
                        FontStretch=""ExtraExpanded""
                            Margin=""290,0,0,0""
                        Height=""30"" VerticalAlignment=""Top""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""20"" Height=""20""
                                    CornerRadius=""20""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""X""
                                        VerticalAlignment=""Top""
                                        HorizontalAlignment=""Center"" Margin=""0,1,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,-20,0,0"" FontWeight=""Bold"" HorizontalAlignment=""Center"" VerticalAlignment=""Top"" Text=""Create New Bus Schedulle""  Height=""26""/>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-125,0,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Depature From"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-55,10,70,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Destination"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,10,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Depature Time"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-124,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Arrive Time"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-38,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-107,10,20,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Date"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""129"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Driver"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-39,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""129"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-129,10,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Price(BWP)"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>


                                        <Button 
                           
                        FontSize=""17""
                        Foreground=""White""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                       
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""                  
                        FontStretch=""ExtraExpanded""
                            Margin=""140,-40,0,0""
                        Height=""40"" Width=""132""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""130"" Height=""38""
                                    CornerRadius=""3""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""CREATE""
                                        VerticalAlignment=""Center""
                                        HorizontalAlignment=""Center"" Margin=""0,0,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                    </StackPanel>
                                </Border>
                            </StackPanel>
                        </StackPanel>
                    </Border>
                </StackPanel>
  
";
            StackPanel Template = (StackPanel)XamlReader.Parse(xaml);
            /*  StackPanel panel1= (StackPanel)Template.Children[0];*/
            Border bd1 = (Border)Template.Children[0];
            StackPanel panel2 = (StackPanel)bd1.Child;
            TextBlock text = (TextBlock)panel2.Children[0];
            Border bd2 = (Border)panel2.Children[1];
            StackPanel panel3 = (StackPanel)bd2.Child;
            ScrollViewer scroll = (ScrollViewer)panel3.Children[1];
            StackPanel panel30 = (StackPanel)scroll.Content;
            Border bd3 = (Border)panel30.Children[0];
            //get text block
            StackPanel panel4 = (StackPanel)bd3.Child;
            TextBlock driver = (TextBlock)panel4.Children[0];
            TextBlock from = (TextBlock)panel4.Children[1];
            TextBlock to = (TextBlock)panel4.Children[2];
            TextBlock via = (TextBlock)panel4.Children[3];
            TextBlock duration = (TextBlock)panel4.Children[4];
            TextBlock date = (TextBlock)panel4.Children[5];
            Border newbd = new Border
            {
                Width = bd3.Width,
                Height = bd3.Height,
                Margin = bd3.Margin,
                Background = bd3.Background,
                CornerRadius = bd3.CornerRadius,
                VerticalAlignment = bd3.VerticalAlignment
            };
            StackPanel panel5 = new StackPanel
            {
                Orientation = Orientation.Horizontal,
            };
            TextBlock Driver = new TextBlock
            {
                FontSize = driver.FontSize,
                Width = driver.Width,
                Height = driver.Height,
                Foreground = driver.Foreground,
                FontWeight = driver.FontWeight,
                Margin = driver.Margin,
                VerticalAlignment = driver.VerticalAlignment
            };
            TextBlock From = new TextBlock
            {
                FontSize = from.FontSize,
                Width = from.Width,
                Height = from.Height,
                Foreground = from.Foreground,
                FontWeight = from.FontWeight,
                Margin = from.Margin,
                VerticalAlignment = from.VerticalAlignment
            };
            TextBlock To = new TextBlock
            {
                FontSize = to.FontSize,
                Width = to.Width,
                Height = to.Height,
                Foreground = to.Foreground,
                FontWeight = to.FontWeight,
                Margin = to.Margin,
                VerticalAlignment = to.VerticalAlignment
            };
            TextBlock Via = new TextBlock
            {
                FontSize = via.FontSize,
                Width = via.Width,
                Height = via.Height,
                Foreground = via.Foreground,
                FontWeight = via.FontWeight,
                Margin = via.Margin,
                VerticalAlignment = via.VerticalAlignment
            };
            TextBlock Duration = new TextBlock
            {
                FontSize = via.FontSize,
                Width = duration.Width,
                Height = duration.Height,
                Foreground = duration.Foreground,
                FontWeight = duration.FontWeight,
                Margin = duration.Margin,
                VerticalAlignment = duration.VerticalAlignment
            };
            TextBlock Date = new TextBlock
            {
                FontSize = date.FontSize,
                Width = date.Width,
                Height = date.Height,
                Foreground = date.Foreground,
                FontWeight = date.FontWeight,
                Margin = date.Margin,
                VerticalAlignment = date.VerticalAlignment
            };
            Driver.Text = "Kagiso Moses";
            From.Text = "Kasane";
            To.Text = "Maun";
            Via.Text = "1200hrs";
            Duration.Text = "1340hrs";
            Date.Text = "8/89/19";
            panel5.Children.Add(Driver);
            panel5.Children.Add(From);
            panel5.Children.Add(To);
            panel5.Children.Add(Via);
            panel5.Children.Add(Duration);
            panel5.Children.Add(Date);
            newbd.Child = panel5;
            panel30.Children.Add(newbd);

            //get buttons
            StackPanel panel6 = (StackPanel)panel2.Children[2];
            Button createnew = (Button)panel6.Children[0];
            createnew.Click += Create;
            Button refresh = (Button)panel6.Children[1];
            //create schedule Form
            StackPanel panel7 = (StackPanel)panel2.Children[3];
            Border bd4 = (Border)panel7.Children[0];
            StackPanel panel8 = (StackPanel)bd4.Child;
            Button close = (Button)panel8.Children[0];
            close.Click += CloseCreate;
            hero.Children.Clear();
            hero.Children.Add(Template);
            hero.Children.Clear();
            refresher();
        }
        private void CloseAdd(object sender, RoutedEventArgs e)
        {
            string xaml = @"
  
       <StackPanel Grid.Row=""2""  xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' >
                    <Border Background=""Transparent"" Width=""848"" Margin=""0,30,0,0"" CornerRadius=""12"" Height=""614"">
                        <StackPanel>
                             <TextBlock Foreground=""#FF301963"" Margin=""10,0,0,0"" Text=""Employees Details"" FontSize=""23"" FontWeight=""ExtraBold""/>
                            <Border CornerRadius=""9"" Background=""#FF2F153A"" Height=""511"" Width=""834"">
                                <StackPanel>
                                    <Border Background=""#FF3F445F"" Height=""34"" CornerRadius=""9"">
                                        <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Firstname"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""40,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Lastname"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""45,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Email"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""156,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Phone"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""95,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Status"" Height=""26""></TextBlock>
                                             
                                        </StackPanel>
                                    </Border>
                                    <ScrollViewer  VerticalScrollBarVisibility=""Hidden"" Height=""468"" Margin=""0,0,0,0"">
                                      <StackPanel>
                                             <Border  Background=""#623ed0"" Height=""34"" VerticalAlignment=""Top"" CornerRadius=""9"" Margin=""0,10,0,0"">
                                            <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Katlo Pole"" Width=""105"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""15,3,0,0"" Width=""110"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Gaborone"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""8,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Width=""200"" Text=""Fancistown"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,3,0,0"" Width=""120"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""3 Ticket(s)"" Height=""26""/>
                                              <TextBlock Foreground=""White"" FontSize=""17"" Margin=""25,3,0,0"" Width=""100"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""P127.00"" Height=""26""/>
                                                 <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,3,0,0"" Width=""15"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""01/12/2002"" Height=""26""/>
                                                  <Button Background=""#FFE21F1F"" Margin=""115,0,0,0"" >


                                                    <Button.Template>
                                                        <ControlTemplate TargetType=""Button"">
                                                            <Border Width=""29"" Height=""28"" CornerRadius=""0,0,9,0""
                                      Margin=""0,0,800,0""
                                         >

                                                                <Border.Background>
                                                                    <ImageBrush ImageSource=""me.png"" ></ImageBrush>
                                                                </Border.Background>


                                                            </Border>
                                                        </ControlTemplate>

                                                    </Button.Template>
                                                </Button >
                                            </StackPanel>
                                        </Border>


                                      </StackPanel>
                                    </ScrollViewer>
                                </StackPanel>
                            </Border>
                            <StackPanel Orientation=""Horizontal"">
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""10,10,650,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">
                                           
                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""CREATE NEW""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""-170,10,0,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">

                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""Refresh""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                            </StackPanel>
<StackPanel Margin=""0,0,0,0"" Opacity=""0"">
                                <Border Background=""#E5120B2F""  CornerRadius=""12"" Width=""318"" Height=""470"">
                                    <StackPanel>
                                        <Button 
                           
                        FontSize=""14""
                        Foreground=""red""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""                  
                        FontStretch=""ExtraExpanded""
                            Margin=""290,0,0,0""
                        Height=""30"" VerticalAlignment=""Top""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""20"" Height=""20""
                                    CornerRadius=""20""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""X""
                                        VerticalAlignment=""Top""
                                        HorizontalAlignment=""Center"" Margin=""0,1,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                       <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,-20,0,0"" FontWeight=""Bold"" HorizontalAlignment=""Center"" VerticalAlignment=""Top"" Text=""Add New Employee""  Height=""26""/>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-125,0,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""First Name(s)"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-55,10,70,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Surname"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-124,0,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Email Address"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                       
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,10,220,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Route"" Width=""50"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-129,10,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Gender"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>

                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Phone"" Width=""150"" Height=""26""/>
                                        
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-38,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <Button 
                           
                        FontSize=""17""
                        Foreground=""White""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""  
                        HorizontalAlignment=""Center""                     
                        FontStretch=""ExtraExpanded""
                            Margin=""0,20,0,0""
                        Height=""40"" Width=""132""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""130"" Height=""38""
                                    CornerRadius=""3""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""CREATE""
                                        VerticalAlignment=""Center""
                                        HorizontalAlignment=""Center"" Margin=""0,0,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                    </StackPanel>
                                </Border>
                            </StackPanel>
                        </StackPanel>
                    </Border>
                </StackPanel>
  
";
            StackPanel Template = (StackPanel)XamlReader.Parse(xaml);




            /*  StackPanel panel1= (StackPanel)Template.Children[0];*/
            Border bd1 = (Border)Template.Children[0];
            StackPanel panel2 = (StackPanel)bd1.Child;
            TextBlock text = (TextBlock)panel2.Children[0];
            Border bd2 = (Border)panel2.Children[1];
            StackPanel panel3 = (StackPanel)bd2.Child;
            ScrollViewer scroll = (ScrollViewer)panel3.Children[1];
            StackPanel panel30 = (StackPanel)scroll.Content;
            Border bd3 = (Border)panel30.Children[0];
            //get text block
            StackPanel panel4 = (StackPanel)bd3.Child;
            TextBlock driver = (TextBlock)panel4.Children[0];
            TextBlock from = (TextBlock)panel4.Children[1];
            TextBlock to = (TextBlock)panel4.Children[2];
            TextBlock via = (TextBlock)panel4.Children[3];
            TextBlock duration = (TextBlock)panel4.Children[4];
            TextBlock date = (TextBlock)panel4.Children[5];
            Button Menu = (Button)panel4.Children[6];
            Border newbd = new Border
            {
                Width = bd3.Width,
                Height = bd3.Height,
                Margin = new Thickness(0, 0, 0, 0),
                Background = bd3.Background,
                CornerRadius = bd3.CornerRadius,
                VerticalAlignment = VerticalAlignment.Top
            };




            panel30.Children.Remove(bd3);



            //get buttons
            StackPanel panel6 = (StackPanel)panel2.Children[2];
            Button createnew = (Button)panel6.Children[0];
            createnew.Click += addnew;
            Button refresh = (Button)panel6.Children[1];
            //create schedule Form
            StackPanel panel7 = (StackPanel)panel2.Children[3];
            Border bd4 = (Border)panel7.Children[0];
            StackPanel panel8 = (StackPanel)bd4.Child;
            Button close = (Button)panel8.Children[0];
            Button btncreate = (Button)panel8.Children[14];
            btncreate.Click += btnadd;
            close.Click += CloseCreate;
            hero.Children.Clear();
            conn.Open();
            SqlCommand command = new SqlCommand("select  FirstName,LastName,Email,Phone,Status from Employees", conn);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Border new1 = new Border
                {
                    Width = bd3.Width,
                    Height = bd3.Height,
                    Margin = new Thickness(0, 3, 0, 0),
                    Background = bd3.Background,
                    CornerRadius = bd3.CornerRadius,
                    VerticalAlignment = VerticalAlignment.Top
                };

                StackPanel panel5 = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                };
                TextBlock Driver = new TextBlock
                {
                    FontSize = driver.FontSize,
                    Width = driver.Width,
                    Height = driver.Height,
                    Foreground = driver.Foreground,
                    FontWeight = driver.FontWeight,
                    Margin = driver.Margin,
                    VerticalAlignment = driver.VerticalAlignment,
                    Text = reader.GetString(0).ToUpper(),
                };
                TextBlock From = new TextBlock
                {
                    FontSize = from.FontSize,
                    Width = from.Width,
                    Height = from.Height,
                    Foreground = from.Foreground,
                    FontWeight = from.FontWeight,
                    Margin = from.Margin,
                    VerticalAlignment = from.VerticalAlignment,
                    Text = reader.GetString(1).ToUpper()
                };
                TextBlock To = new TextBlock
                {
                    FontSize = to.FontSize,
                    Width = to.Width,
                    Height = to.Height,
                    Foreground = to.Foreground,
                    FontWeight = to.FontWeight,
                    Margin = to.Margin,
                    VerticalAlignment = to.VerticalAlignment,
                    Text = reader.GetString(2).ToUpper()
                };
                TextBlock dep = new TextBlock
                {
                    FontSize = via.FontSize,
                    Width = via.Width,
                    Height = via.Height,
                    Foreground = via.Foreground,
                    FontWeight = via.FontWeight,
                    Margin = via.Margin,
                    VerticalAlignment = via.VerticalAlignment,
                    Text = "On Schedule"
                };
                TextBlock arr = new TextBlock
                {
                    FontSize = via.FontSize,
                    Width = duration.Width,
                    Height = duration.Height,
                    Foreground = duration.Foreground,
                    FontWeight = duration.FontWeight,
                    Margin = duration.Margin,
                    VerticalAlignment = duration.VerticalAlignment,
                    Text = "On Schedule"
                };
                /*   TextBlock Date = new TextBlock
                   {
                       FontSize = date.FontSize,
                       Width = date.Width,
                       Height = date.Height,
                       Foreground = date.Foreground,
                       FontWeight = date.FontWeight,
                       Margin = date.Margin,
                       VerticalAlignment = date.VerticalAlignment,
                       Text = reader.GetString(4).ToUpper()
                   };*/
                panel5.Children.Add(Driver);
                panel5.Children.Add(From); panel5.Children.Add(To);
                panel5.Children.Add(dep); panel5.Children.Add(arr);
                /*    panel5.Children.Add(Date);*/

                Button Men = new Button
                {
                    Background = Menu.Background,
                    Margin = Menu.Margin,
                };
                Men.Template = Menu.Template;
                panel5.Children.Add(Men);
                new1.Child = panel5;
                /*   panel7.Margin = new Thickness(0, -500, 0, 0);
                   panel7.Opacity = 1;*/
                panel30.Children.Add(new1);

            }

            conn.Close();
            hero.Children.Add(Template);
        }
        private void Reports_Click(object sender, RoutedEventArgs e)
        {
            report1.Margin = new Thickness(1000, 32, 10, 20);
            string xaml = @"
  
       <StackPanel Grid.Row=""2""  xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' >
                    <Border Background=""Transparent"" Width=""848"" Margin=""0,30,0,0"" CornerRadius=""12"" Height=""614"">
                        <StackPanel>
                             <TextBlock Foreground=""#FF301963"" Margin=""10,0,0,0"" Text=""Employees Details"" FontSize=""23"" FontWeight=""ExtraBold""/>
                            <Border CornerRadius=""9"" Background=""#FF2F153A"" Height=""511"" Width=""834"">
                                <StackPanel>
                                    <Border Background=""#FF3F445F"" Height=""34"" CornerRadius=""9"">
                                        <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Firstname"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""40,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Lastname"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""45,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Email"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""156,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Phone"" Height=""26""></TextBlock>
                                            <TextBlock Foreground=""White"" FontSize=""17"" Margin=""95,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Status"" Height=""26""></TextBlock>
                                             
                                        </StackPanel>
                                    </Border>
                                    <ScrollViewer  VerticalScrollBarVisibility=""Hidden"" Height=""468"" Margin=""0,0,0,0"">
                                      <StackPanel>
                                             <Border  Background=""#623ed0"" Height=""34"" VerticalAlignment=""Top"" CornerRadius=""9"" Margin=""0,10,0,0"">
                                            <StackPanel Orientation=""Horizontal"" Margin=""0,0,0,0"" >
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""10,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Katlo Pole"" Width=""105"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""15,3,0,0"" Width=""110"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Gaborone"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""8,3,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Width=""200"" Text=""Fancistown"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,3,0,0"" Width=""120"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""3 Ticket(s)"" Height=""26""/>
                                                <TextBlock Foreground=""White"" FontSize=""17"" Margin=""25,3,0,0"" Width=""100"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""P127.00"" Height=""26""/>
                                                 <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,3,0,0"" Width=""15"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""01/12/2002"" Height=""26""/>
                                                  <Button Background=""#FFE21F1F"" Margin=""115,0,0,0"" >

                                                    <Button.Template>
                                                        <ControlTemplate TargetType=""Button"">
                                                            <Border Width=""29"" Height=""28"" CornerRadius=""0,0,9,0""
                                      Margin=""0,0,800,0""
                                         >

                                                                <Border.Background>
                                                                    <ImageBrush ImageSource=""me.png"" ></ImageBrush>
                                                                </Border.Background>


                                                            </Border>
                                                        </ControlTemplate>

                                                    </Button.Template>
                                                </Button >
                                            </StackPanel>
                                        </Border>


                                      </StackPanel>
                                    </ScrollViewer>
                                </StackPanel>
                            </Border>
                            <StackPanel Orientation=""Horizontal"">
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""10,10,650,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">
                                           
                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""CREATE NEW""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                                <Button Foreground=""White"" FontWeight=""Bold"" Width=""174"" Height=""40""
                                        Margin=""-170,10,0,0""
                                        FontSize=""17"">
                                    <Button.Style>
                                        <Style TargetType=""Button"">

                                        </Style>
                                    </Button.Style>
                                    <Button.Template>
                                        <ControlTemplate>
                                            <Border CornerRadius=""9"" Background=""#623ed0""  >
                                                <ContentPresenter HorizontalAlignment=""Center"" VerticalAlignment=""Center"" Content=""Refresh""/>
                                            </Border>
                                        </ControlTemplate>
                                    </Button.Template>
                                </Button>
                            </StackPanel>
<StackPanel Margin=""0,0,0,0"" Opacity=""0"">
                                <Border Background=""#E5120B2F""  CornerRadius=""12"" Width=""318"" Height=""470"">
                                    <StackPanel>
                                        <Button 
                           
                        FontSize=""14""
                        Foreground=""red""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""                  
                        FontStretch=""ExtraExpanded""
                            Margin=""290,0,0,0""
                        Height=""30"" VerticalAlignment=""Top""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""20"" Height=""20""
                                    CornerRadius=""20""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""X""
                                        VerticalAlignment=""Top""
                                        HorizontalAlignment=""Center"" Margin=""0,1,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                       <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,-20,0,0"" FontWeight=""Bold"" HorizontalAlignment=""Center"" VerticalAlignment=""Top"" Text=""Add New Employee""  Height=""26""/>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-125,0,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""First Name(s)"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-55,10,70,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Surname"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-124,0,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Email Address"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                       
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""0,10,220,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Route"" Width=""50"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""280"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""-129,10,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Gender"" Width=""150"" Height=""26""/>
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""20,0,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>

                                        <TextBlock Foreground=""White"" FontSize=""17"" Margin=""170,-65,0,0"" FontWeight=""Bold"" VerticalAlignment=""Top"" Text=""Phone"" Width=""150"" Height=""26""/>
                                        
                                        <Border  BorderBrush=""Black"" BorderThickness=""1.5"" Background=""#FF7D8484"" Margin=""169,-38,0,0"" HorizontalAlignment=""Left"" CornerRadius=""3"" Width=""130"" Height=""38"">
                                            <TextBox BorderBrush=""Transparent"" BorderThickness=""0"" TextAlignment=""Center"" Foreground=""White"" FontSize=""17"" VerticalContentAlignment=""Center"" Background=""Transparent"" />
                                        </Border>
                                        <Button 
                           
                        FontSize=""17""
                        Foreground=""White""
                        FontWeight=""Bold""
                        Grid.Column=""1""
                      
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""  
                        HorizontalAlignment=""Center""                     
                        FontStretch=""ExtraExpanded""
                            Margin=""0,20,0,0""
                        Height=""40"" Width=""132""
                            >

                                            <Button.Style>
                                                <Style TargetType=""Button"">
                                                    <Setter Property=""Background"" Value=""#00FF00""/>
                                                    <Style.Triggers>
                                                        <Trigger Property=""IsMouseOver"" Value=""True"">
                                                            <Setter Property=""Background"" Value=""#FFE09919""/>
                                                        </Trigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Button.Style>
                                            <Button.Template>
                                                <ControlTemplate TargetType=""Button"">
                                                    <Border Width=""130"" Height=""38""
                                    CornerRadius=""3""
                                    Background=""{TemplateBinding Background}""
                                         >
                                                        <ContentPresenter
                                        Content=""CREATE""
                                        VerticalAlignment=""Center""
                                        HorizontalAlignment=""Center"" Margin=""0,0,0,0"" />


                                                    </Border>
                                                </ControlTemplate>

                                            </Button.Template>
                                        </Button>
                                    </StackPanel>
                                </Border>
                            </StackPanel>
                        </StackPanel>
                    </Border>
                </StackPanel>
  
";
            StackPanel Template = (StackPanel)XamlReader.Parse(xaml);




            /*  StackPanel panel1= (StackPanel)Template.Children[0];*/
            Border bd1 = (Border)Template.Children[0];
            StackPanel panel2 = (StackPanel)bd1.Child;
            TextBlock text = (TextBlock)panel2.Children[0];
            Border bd2 = (Border)panel2.Children[1];
            StackPanel panel3 = (StackPanel)bd2.Child;
            ScrollViewer scroll = (ScrollViewer)panel3.Children[1];
            StackPanel panel30 = (StackPanel)scroll.Content;
            Border bd3 = (Border)panel30.Children[0];
            //get text block
            StackPanel panel4 = (StackPanel)bd3.Child;
            TextBlock driver = (TextBlock)panel4.Children[0];
            TextBlock from = (TextBlock)panel4.Children[1];
            TextBlock to = (TextBlock)panel4.Children[2];
            TextBlock via = (TextBlock)panel4.Children[3];
            TextBlock duration = (TextBlock)panel4.Children[4];
            TextBlock date = (TextBlock)panel4.Children[5];
            Button Menu = (Button)panel4.Children[6];
            Border newbd = new Border
            {
                Width = bd3.Width,
                Height = bd3.Height,
                Margin = new Thickness(0, 0, 0, 0),
                Background = bd3.Background,
                CornerRadius = bd3.CornerRadius,
                VerticalAlignment = VerticalAlignment.Top
            };




            panel30.Children.Remove(bd3);



            //get buttons
            StackPanel panel6 = (StackPanel)panel2.Children[2];
            Button createnew = (Button)panel6.Children[0];
            createnew.Click += addnew;
            Button refresh = (Button)panel6.Children[1];
            //create schedule Form
            StackPanel panel7 = (StackPanel)panel2.Children[3];
            Border bd4 = (Border)panel7.Children[0];
            StackPanel panel8 = (StackPanel)bd4.Child;
            Button close = (Button)panel8.Children[0];
            Button btncreate = (Button)panel8.Children[14];
            btncreate.Click += btnadd;
            close.Click += CloseCreate;
            hero.Children.Clear();
            conn.Open();
            SqlCommand command = new SqlCommand("select  FirstName,LastName,Email,Phone,Status from Employees", conn);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Border new1 = new Border
                {
                    Width = bd3.Width,
                    Height = bd3.Height,
                    Margin = new Thickness(0, 3, 0, 0),
                    Background = bd3.Background,
                    CornerRadius = bd3.CornerRadius,
                    VerticalAlignment = VerticalAlignment.Top
                };

                StackPanel panel5 = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                };
                TextBlock Driver = new TextBlock
                {
                    FontSize = driver.FontSize,
                    Width = driver.Width,
                    Height = driver.Height,
                    Foreground = driver.Foreground,
                    FontWeight = driver.FontWeight,
                    Margin = driver.Margin,
                    VerticalAlignment = driver.VerticalAlignment,
                    Text = reader.GetString(0).ToUpper(),
                };
                TextBlock From = new TextBlock
                {
                    FontSize = from.FontSize,
                    Width = from.Width,
                    Height = from.Height,
                    Foreground = from.Foreground,
                    FontWeight = from.FontWeight,
                    Margin = from.Margin,
                    VerticalAlignment = from.VerticalAlignment,
                    Text = reader.GetString(1).ToUpper()
                };
                TextBlock To = new TextBlock
                {
                    FontSize = to.FontSize,
                    Width = to.Width,
                    Height = to.Height,
                    Foreground = to.Foreground,
                    FontWeight = to.FontWeight,
                    Margin = to.Margin,
                    VerticalAlignment = to.VerticalAlignment,
                    Text = reader.GetString(2).ToUpper()
                };
                TextBlock dep = new TextBlock
                {
                    FontSize = via.FontSize,
                    Width = via.Width,
                    Height = via.Height,
                    Foreground = via.Foreground,
                    FontWeight = via.FontWeight,
                    Margin = via.Margin,
                    VerticalAlignment = via.VerticalAlignment,
                    Text = reader.GetString(4).ToUpper()
                };
                TextBlock arr = new TextBlock
                {
                    FontSize = via.FontSize,
                    Width = duration.Width,
                    Height = duration.Height,
                    Foreground = duration.Foreground,
                    FontWeight = duration.FontWeight,
                    Margin = duration.Margin,
                    VerticalAlignment = duration.VerticalAlignment,
                    Text = "On Schedule"
                };
                /*   TextBlock Date = new TextBlock
                   {
                       FontSize = date.FontSize,
                       Width = date.Width,
                       Height = date.Height,
                       Foreground = date.Foreground,
                       FontWeight = date.FontWeight,
                       Margin = date.Margin,
                       VerticalAlignment = date.VerticalAlignment,
                       Text = reader.GetString(4).ToUpper()
                   };*/
                panel5.Children.Add(Driver);
                panel5.Children.Add(From); panel5.Children.Add(To);
                panel5.Children.Add(dep); panel5.Children.Add(arr);
                /*    panel5.Children.Add(Date);*/

                Button Men = new Button
                {
                    Background = Menu.Background,
                    Margin = Menu.Margin,
                };
                Men.Template = Menu.Template;
                panel5.Children.Add(Men);
                new1.Child = panel5;
             /*   panel7.Margin = new Thickness(0, -500, 0, 0);
                panel7.Opacity = 1;*/
                panel30.Children.Add(new1);

            }

            conn.Close();
            hero.Children.Add(Template);
        }

        private void Report_Click(object sender, RoutedEventArgs e)
        {

            string xaml = @"
  
       <Border Background=""#E5041A33"" CornerRadius=""9"" Margin=""0,0,0,0"" xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' >
                       <StackPanel>
            <TextBlock Text=""Select Report To Generate"" Foreground=""White"" FontSize=""17"" Margin=""0,10,0,0"" FontWeight=""Bold"" HorizontalAlignment=""Center""/>
            <StackPanel Margin=""30"">
                <RadioButton Content=""Details About Customers And Total Sale Made"" FontSize=""16"" FontWeight=""Bold"" Foreground=""White""/>
                <RadioButton Content=""Bus Schedules Made And Drivers"" FontSize=""16"" FontWeight=""Bold"" Foreground=""White""/>
                <StackPanel Orientation=""Horizontal"" Margin=""0,50,0,0"">
                    <Button  
                      
                        FontSize=""22""
                        Foreground=""White""
                        FontWeight=""Bold""
                        Margin=""0,0,0,0""
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""                  
                        FontStretch=""ExtraExpanded"" 
                         
                            >


                        <Button.Style>
                            <Style TargetType=""Button"">
                                <Setter Property=""Background"" Value=""#FF073379""/>
                                <Style.Triggers>
                                    <Trigger Property=""IsMouseOver"" Value=""True"">
                                        <Setter Property=""Background"" Value=""#692EC4""/>
                                    </Trigger>
                                </Style.Triggers>
                            </Style>
                        </Button.Style>
                        <Button.Template>
                            <ControlTemplate TargetType=""Button"">
                                <Border Width=""245"" Height=""43"" CornerRadius=""9""
                                    Background=""{TemplateBinding Background}""
                                         >
                                    <StackPanel VerticalAlignment=""Center"" HorizontalAlignment=""Center"">

                                        <TextBlock Text=""Generate Report""
                                                           Foreground=""White""
                                                           FontSize=""15""
                                                             Height=""20""
                                                           />
                                    </StackPanel>
                                </Border>
                            </ControlTemplate>

                        </Button.Template>
                    </Button>
                    <Button  HorizontalAlignment=""Center""
                    
                        FontSize=""22""
                        Foreground=""White""
                        FontWeight=""Bold""
                        Margin=""100,0,0,0""
                        BorderThickness=""0""
                        FontFamily=""Montserrat""
                        Cursor=""Hand""                  
                        FontStretch=""ExtraExpanded"" 
                         
                            >


                        <Button.Style>
                            <Style TargetType=""Button"">
                                <Setter Property=""Background"" Value=""#FFE64B28""/>
                                <Style.Triggers>
                                    <Trigger Property=""IsMouseOver"" Value=""True"">
                                        <Setter Property=""Background"" Value=""#692EC4""/>
                                    </Trigger>
                                </Style.Triggers>
                            </Style>
                        </Button.Style>
                        <Button.Template>
                            <ControlTemplate TargetType=""Button"">
                                <Border Width=""125"" Height=""43"" CornerRadius=""9""
                                    Background=""{TemplateBinding Background}""
                                         >
                                    <StackPanel VerticalAlignment=""Center"" HorizontalAlignment=""Center"">

                                        <TextBlock Text=""Close""
                                                           Foreground=""White""
                                                           FontSize=""15""
                                                             Height=""20""
                                                           />
                                    </StackPanel>
                                </Border>
                            </ControlTemplate>

                        </Button.Template>
                    </Button>
                </StackPanel>
            </StackPanel>
        </StackPanel>
                    </Border>
               
  
";
           Border Template = (Border)XamlReader.Parse(xaml);
            Window win = new Window {
                Height = 260,
                Width = 600,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                AllowsTransparency = true,
                Background=new SolidColorBrush(Colors.Transparent),
                WindowStyle=WindowStyle.None,
                
            };
            win.Content = Template;
            win.ShowInTaskbar = false;


            StackPanel stack = (StackPanel)Template.Child as StackPanel;
            StackPanel stack1 = (StackPanel)stack.Children[1] as StackPanel;
            RadioButton radio1 = (RadioButton)stack1.Children[0] as RadioButton;
            RadioButton radio2 = (RadioButton)stack1.Children[1] as RadioButton;
            StackPanel stack2 = (StackPanel)stack1.Children[2] as StackPanel;
            Button gen = (Button)stack2.Children[0] as Button;
            gen.Click += generate;
            if (radio1.IsChecked == true)
            {
                radio2.IsChecked = false;
            }
            if (radio2.IsChecked == true)
            {
                radio1.IsChecked = false;
            }
            win.Show();
            /*if (change == 1)
            {
                hero.Children.Clear();
                hero.Children.Add(og);
                hero.Children.Add(report1);
                og.Opacity= 0;
                og.Margin = og.Margin;
                report1.Margin = new Thickness(0, -590, 0, 0);
               *//* og.Opacity = 0;*//*
            }
            else
            {
                og.Opacity = 0;
                report1.Margin = new Thickness(0, -590, 0, 0);
            }*/
         


        }

        /*  public void reload()
           {
               og.Opacity = 1;
               report1.Margin = new Thickness(0, 10, 0, 0);

               conn.Open();
               string queryString1 = "select count(*) from BUS_SCHEDULES";
               SqlCommand command1 = new SqlCommand(queryString1, conn);
               int count = (int)command1.ExecuteScalar();
               num.Text = string.Empty;
               num.Text = count.ToString();

               conn.Close();

               conn.Open();
               string queryString2 = "select count(*) from History";
               SqlCommand command2 = new SqlCommand(queryString2, conn);
               int count2 = (int)command2.ExecuteScalar();
               num2.Text = string.Empty;
               num2.Text = count2.ToString();

               conn.Close();




               hero.Children.Clear();
               parent.Children.Clear();
               conn.Open();
               SqlCommand command = new SqlCommand("select  From_T,To_T,Ticket_Id,Price from History", conn);
               SqlDataReader reader = command.ExecuteReader();
               while (reader.Read())
               {
                   Border bd = new Border
                   {
                       Background = BD.Background,
                       Height = BD.Height,
                       Width = BD.Width,
                       CornerRadius = BD.CornerRadius,
                       VerticalAlignment = BD.VerticalAlignment,
                       Margin = BD.Margin
                   };
                   StackPanel stack = new StackPanel
                   {
                       Orientation = Orientation.Horizontal,
                   };
                   TextBlock name = new TextBlock
                   {
                       Height = t1.Height,
                       Width = t1.Width,
                       Foreground = t1.Foreground,
                       FontWeight = t1.FontWeight,
                       VerticalAlignment = t1.VerticalAlignment,
                       Margin = t1.Margin,
                       FontSize = t1.FontSize,
                       Text = "Katlo Pole"

                   };
                   TextBlock from = new TextBlock
                   {
                       Height = t2.Height,
                       Width = t2.Width,
                       Foreground = t2.Foreground,
                       FontWeight = t2.FontWeight,
                       VerticalAlignment = t2.VerticalAlignment,
                       Margin = t2.Margin,
                       FontSize = t1.FontSize,
                       Text = reader.GetString(0)

                   };
                   TextBlock to = new TextBlock
                   {
                       Height = t3.Height,
                       Width = t3.Width,
                       Foreground = t3.Foreground,
                       FontWeight = t3.FontWeight,
                       VerticalAlignment = t3.VerticalAlignment,
                       Margin = t3.Margin,
                       FontSize = t3.FontSize,
                       Text = reader.GetString(1)
                   };
                   TextBlock qnt = new TextBlock
                   {
                       Height = t4.Height,
                       Width = t4.Width,
                       Foreground = t4.Foreground,
                       FontWeight = t4.FontWeight,
                       VerticalAlignment = t4.VerticalAlignment,
                       Margin = t4.Margin,
                       FontSize = t4.FontSize,
                       Text = reader.GetString(2)
                   };
                   TextBlock price = new TextBlock
                   {
                       Height = t5.Height,
                       Width = t5.Width,
                       Foreground = t5.Foreground,
                       FontWeight = t5.FontWeight,
                       VerticalAlignment = t5.VerticalAlignment,
                       Margin = t5.Margin,
                       FontSize = t5.FontSize,
                       Text = reader.GetString(3)
                   };
                   stack.Children.Add(name);
                   stack.Children.Add(from);
                   stack.Children.Add(to);
                   stack.Children.Add(qnt);
                   stack.Children.Add(price);
                   bd.Child = stack;
                   parent.Children.Add(bd);

               }
               conn.Close();

               hero.Children.Add(og);
               og.Opacity = 0;
               report1.Margin = new Thickness(0, -590, 0, 0);
           }*/

        private void generate(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender as Button;
            StackPanel stack = (StackPanel)btn.Parent;
            StackPanel stack1= (StackPanel)stack.Parent;
            RadioButton radio1 = (RadioButton)stack1.Children[0] as RadioButton;
            RadioButton radio2 = (RadioButton)stack1.Children[1] as RadioButton;

           if(radio1.IsChecked == true)
            {
                var date=DateTime.Now;
                which.Content = "Report:Details About Customers And Total Sale Made";
                on.Content = date.ToString();
                v1.Text = "Customer Names";
                v2.Text = "Email Address";
                v3.Text = "From";
                v4.Text = "Destination";
                v5.Text = "Paid";
                try
                {
                    Border b1 = (Border)v1.Parent;

                    b1.Child = null;
                    Border b2 = (Border)v2.Parent;
                    b2.Child = null;
                    Border b3 = (Border)v3.Parent;
                    b3.Child = null;
                    Border b4 = (Border)v4.Parent;
                    b4.Child = null;
                    Border b5 = (Border)v5.Parent;
                    b5.Child = null;
                }
                catch
                {
                    StackPanel b1 = (StackPanel)v1.Parent;

                    b1.Children.Remove(v1);
                    StackPanel b2 = (StackPanel)v2.Parent;
                    b2.Children.Remove(v2);
                    StackPanel b3 = (StackPanel)v3.Parent;
                    b3.Children.Remove(v3);
                    StackPanel b4 = (StackPanel)v4.Parent;
                    b4.Children.Remove(v4);
                    StackPanel b5 = (StackPanel)v5.Parent;
                    b5.Children.Remove(v5);
                }
                names.Children.Clear();
                names.Children.Add(v1);
                emai.Children.Clear();
                emai.Children.Add(v2);
                from.Children.Clear();
                from.Children.Add(v3);
                dest.Children.Clear();
                dest.Children.Add(v4);
                paid.Children.Clear();
                paid.Children.Add(v5);

                conn.Open();
                SqlCommand command = new SqlCommand("select  From_T,To_T,Ticket_Id,Price,Names,email from History", conn);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string cash = reader.GetString(3).ToString().Trim('P');

                    double ash = double.Parse(cash);
                    totalmoney += ash;



                    addname(reader.GetString(4).ToString());
                    addemail(reader.GetString(5));
                    addfrom(reader.GetString(0).ToString());
                    addto(reader.GetString(1).ToString());
                    addprice(reader.GetString(3).ToString());
                   
                    txtcash.Text = "P" + totalmoney.ToString() + ".00";
                }
                dest.Children.Add(total);
                paid.Children.Add(cash1);

                conn.Close();
                if (change == 1)
                {
                    hero.Children.Clear();
                    hero.Children.Add(og);
                    hero.Children.Add(report1);
                    og.Opacity = 0;
                    og.Margin = og.Margin;
                    report1.Margin = new Thickness(0, -590, 0, 0);
                    /* og.Opacity = 0;*/
                }
                else
                {
                    og.Opacity = 0;
                    report1.Margin = new Thickness(0, -590, 0, 0);
                }
            }
           else if(radio2.IsChecked == true)
            {
                var date = DateTime.Now;
                which.Content = "Report:Bus Schedules Made And Drivers";
                on.Content = date.ToString();

                v1.Text = "Driver";
                v2.Text = "From";
                v3.Text = "Destination";
                v4.Text = "Date";
                v5.Text = "Bus ID";
                try
                {
                    Border b1 = (Border)v1.Parent;

                    b1.Child = null;
                    Border b2 = (Border)v2.Parent;
                    b2.Child = null;
                    Border b3 = (Border)v3.Parent;
                    b3.Child = null;
                    Border b4 = (Border)v4.Parent;
                    b4.Child = null;
                    Border b5 = (Border)v5.Parent;
                    b5.Child = null;
                }
                catch
                {
                    StackPanel b1 = (StackPanel)v1.Parent;

                    b1.Children.Remove(v1);
                    StackPanel b2 = (StackPanel)v2.Parent;
                    b2.Children.Remove(v2);
                    StackPanel b3 = (StackPanel)v3.Parent;
                    b3.Children.Remove(v3);
                    StackPanel b4 = (StackPanel)v4.Parent;
                    b4.Children.Remove(v4);
                    StackPanel b5 = (StackPanel)v5.Parent;
                    b5.Children.Remove(v5);
                }
                names.Children.Clear();
                names.Children.Add(v1);
                emai.Children.Clear();
                emai.Children.Add(v2);
                from.Children.Clear();
                from.Children.Add(v3);
                dest.Children.Clear();
                dest.Children.Add(v4);
                paid.Children.Clear();
                paid.Children.Add(v5);
               /* dest.Children.Remove(total);
                paid.Children.Remove(cash1);*/


                conn.Open();
                SqlCommand command = new SqlCommand("select DRIVER,BUS_FROM,BUS_TO,Bus_Date,BUS_ID from BUS_SCHEDULES", conn);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    



                    addname(reader.GetString(0).ToString().ToUpper());
                    addemail(reader.GetString(1).ToUpper());
                    addfrom(reader.GetString(2).ToString().ToUpper());
                    addto(reader.GetString(3).ToString().ToUpper());
                    addprice(reader.GetString(4).ToString().ToUpper());
                }
                conn.Close();


                    if (change == 1)
                {
                    hero.Children.Clear();
                    hero.Children.Add(og);
                    hero.Children.Add(report1);
                    og.Opacity = 0;
                    og.Margin = og.Margin;
                    report1.Margin = new Thickness(0, -590, 0, 0);
                    /* og.Opacity = 0;*/
                }
                else
                {
                    og.Opacity = 0;
                    report1.Margin = new Thickness(0, -590, 0, 0);
                }
            }
           

            Window window = Window.GetWindow(sender as Button);
            window.Close();

        }
    }
}
